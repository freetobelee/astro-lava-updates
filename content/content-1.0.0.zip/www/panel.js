
/* Astro Lava control panel: effect picks, sliders, webcam/phone mapping, optional Pi/USB import. */
const $ = (s, r=document) => r.querySelector(s);
let S = null;

async function api(path, body, method) {
  const opt = { method: method || (body === undefined ? 'GET' : 'POST'), headers: {} };
  if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
  const r = await fetch(path, opt);
  const t = await r.text();
  if (!r.ok) throw new Error(t || r.status);
  try { return JSON.parse(t); } catch (e) { return t; }
}

function setStatus(msg, ok) {
  const el = $('#status'); el.textContent = msg; el.className = 'status ' + (ok === true ? 'ok' : ok === false ? 'bad' : '');
}

async function refresh() {
  S = await api('/api/state');
  $('#ver').textContent = 'v' + (S.version || '0.2.2');
  const fx = $('#fx'); fx.innerHTML = '';
  (S.effects || []).forEach(e => {
    const b = document.createElement('button');
    b.textContent = e.label; if (e.id === S.effect) b.className = 'on';
    b.onclick = () => save({ effect: e.id });
    fx.appendChild(b);
  });
  renderSliders();
  const sc = S.scan || {};
  $('#scanInfo').textContent = S.hasScan
    ? ('Scan from ' + (sc.source || '?') + (sc.created ? ' · ' + String(sc.created).replace('T', ' ').slice(0, 16) : '') + (sc.hasFireplace ? ' · fireplace marked' : ' · no fireplace box'))
    : 'No scan yet. Effects still run full-screen.';
  $('#piUrl').value = S.piUrl || '';
  const cam = $('#camInfo');
  if (cam) {
    if (S.usbCameras > 0) cam.textContent = 'Webcam ready' + (S.usbCamName ? ': ' + S.usbCamName : '') + '. Map with webcam projects black, white, then the checkerboard, and saves the scan. The camera is released afterwards. Phone photos remain a fallback.';
    else if (S.usbHost) cam.textContent = 'No USB camera found. Plug the C615 into the Astro\'s USB (or a hub), or map with phone photos instead.';
    else cam.textContent = "This Astro doesn't expose USB host, so the webcam can't be used. Map with your phone instead.";
  }
  const camBtn = $('#mapCam');
  if (camBtn) camBtn.disabled = !!S.mapBusy;
  const fps = S.fps ? Math.round(S.fps) + ' fps' : '';
  const upd = $('#updateInfo');
  if (upd) {
    const bits = [];
    bits.push('App v' + (S.version || '') + ' · content ' + (S.contentVersion || '?') + (S.contentSource && S.contentSource !== 'current' ? ' (' + S.contentSource + ')' : ''));
    if (S.updateStatus) bits.push(S.updateStatus);
    upd.textContent = bits.join(' — ');
  }
  const chk = $('#checkUpdate');
  if (chk) chk.disabled = !!S.updateBusy;
  if (S.updateStatus) setStatus(S.updateStatus, S.updateError ? false : true);
  else if (S.mapStatus) setStatus(S.mapStatus, S.mapError ? false : true);
  else setStatus((S.banner ? S.banner + '  ·  ' : '') + (S.effect || '') + (fps ? '  ·  ' + fps : ''), true);
}

function slider(id, label, min, max, step, val, key) {
  const wrap = document.createElement('label');
  wrap.innerHTML = label + ' <span class=row><input type=range min='+min+' max='+max+' step='+step+' value="'+val+'"> <output>'+val+'</output></span>';
  const inp = wrap.querySelector('input'), out = wrap.querySelector('output');
  inp.oninput = () => { out.textContent = inp.value; };
  inp.onchange = () => { const o = {}; o[key] = +inp.value; save(o); };
  return wrap;
}
function toggle(label, key, val) {
  const wrap = document.createElement('label');
  wrap.innerHTML = '<span class=row>'+label+' <input type=checkbox '+(val?'checked':'')+'></span>';
  wrap.querySelector('input').onchange = ev => { const o = {}; o[key] = ev.target.checked; save(o); };
  return wrap;
}
function select(label, key, val, opts) {
  const wrap = document.createElement('label');
  wrap.appendChild(document.createTextNode(label + ' '));
  const s = document.createElement('select');
  opts.forEach(([v,l]) => { const o = document.createElement('option'); o.value=v; o.textContent=l; if (v===val) o.selected=true; s.appendChild(o); });
  s.onchange = () => { const o = {}; o[key] = s.value; save(o); };
  wrap.appendChild(s); return wrap;
}

function fieldValue(key, fallback) {
  if (S[key] !== undefined && S[key] !== null) return S[key];
  return fallback;
}
function renderFromSchema(box, sliders) {
  sliders.forEach(s => {
    const key = s.key;
    if (!key) return;
    const typ = s.type || (s.options ? 'select' : (typeof s.default === 'boolean' ? 'toggle' : 'slider'));
    if (typ === 'toggle') box.appendChild(toggle(s.label || key, key, !!fieldValue(key, s.default)));
    else if (typ === 'select') box.appendChild(select(s.label || key, key, fieldValue(key, s.default), s.options || []));
    else box.appendChild(slider(key, s.label || key, s.min, s.max, s.step || 0.05, fieldValue(key, s.default), key));
  });
}
function renderSliders() {
  const box = $('#sliders'); box.innerHTML = '<h2>Settings</h2>';
  const e = S.effect;
  const def = (S.effects || []).find(x => x.id === e);
  if (def && def.sliders && def.sliders.length) {
    renderFromSchema(box, def.sliders);
    return;
  }
  box.appendChild(slider('int', 'Intensity', 0.2, 2, 0.05, S.intensity, 'intensity'));
  box.appendChild(slider('spd', 'Speed', 0.2, 3, 0.05, S.fxSpeed, 'fxSpeed'));
  if (e === 'wax' || e === 'clock') {
    box.appendChild(slider('heat', 'Heat', 0.3, 3, 0.05, S.heat, 'heat'));
    box.appendChild(slider('size', 'Blob size', 0.5, 2, 0.05, S.size, 'size'));
    box.appendChild(slider('blobs', 'Blobs', 2, 16, 1, S.blobs, 'blobs'));
    box.appendChild(slider('pal', 'Palette', 0, 19, 1, S.palette, 'palette'));
    if (e === 'clock') box.appendChild(select('Timezone', 'tz', S.tz, [
      ['America/Los_Angeles','Pacific'], ['America/Denver','Mountain'], ['America/Chicago','Central'],
      ['America/New_York','Eastern'], ['UTC','UTC']
    ]));
  }
  if (e === 'lava') {
    box.appendChild(toggle('Fireplace blob + eyes', 'blobOn', S.blobOn));
    box.appendChild(slider('bsize', 'Blob size', 0.2, 1.5, 0.05, S.blobSize, 'blobSize'));
    box.appendChild(slider('cs', 'Blob colour speed', 0.2, 3, 0.05, S.colorSpeed, 'colorSpeed'));
  }
  if (e === 'rain') {
    box.appendChild(select('Weather', 'weather', S.weather, [['auto','Auto (take turns)'],['rain','Rain'],['snow','Snow']]));
    box.appendChild(toggle('Fireplace fire', 'fireOn', S.fireOn));
  }
  if (e === 'ivy') {
    box.appendChild(toggle('Fireplace glow', 'glowOn', S.glowOn));
    box.appendChild(toggle('Moving sun', 'sunOn', S.sunOn));
    box.appendChild(slider('ss', 'Sun speed', 0.2, 3, 0.05, S.sunSpeed, 'sunSpeed'));
  }
  if (e === 'sweep') {
    box.appendChild(select('Direction', 'sweepMode', S.sweepMode, [['auto','Auto (top every other turn)'],['top','From the top'],['side','From the side']]));
  }
  box.appendChild(toggle('Show mask (debug)', 'debugMask', S.debugMask));
}

async function save(partial) {
  try { S = await api('/api/state', partial); await refresh(); }
  catch (e) { setStatus(String(e.message || e), false); }
}

$('#piImport').onclick = async () => {
  try {
    setStatus('Importing from the Pi…');
    await api('/api/import/pi', { url: $('#piUrl').value || S.piUrl });
    await refresh(); setStatus('Imported the Pi scan', true);
  } catch (e) { setStatus('Pi import: ' + (e.message || e), false); }
};
$('#usbImport').onclick = async () => {
  try { await api('/api/import/usb', {}); await refresh(); setStatus('Imported from USB', true); }
  catch (e) { setStatus('USB: ' + (e.message || e), false); }
};
$('#scanClear').onclick = async () => {
  if (!confirm('Clear the saved scan?')) return;
  try { await api('/api/scan/clear', {}); await refresh(); } catch (e) { setStatus(String(e.message||e), false); }
};

/* ---- mapping UI ---- */
const MapUI = {
  photos: [], // {frame, url, img}
  mask: null, fire: null, dragging: null,
};
$('#mapCam').onclick = () => mapWebcam();
$('#mapStart').onclick = () => mapBegin(false);

async function mapWebcam() {
  try {
    setStatus('Starting webcam mapping…');
    await api('/api/map/webcam', {});
    for (let i = 0; i < 90; i++) {
      await new Promise(r => setTimeout(r, 700));
      await refresh();
      if (!S.mapBusy) {
        setStatus(S.mapStatus || (S.mapError ? 'Webcam mapping failed.' : 'Webcam map saved.'), S.mapError ? false : true);
        return;
      }
    }
    setStatus(S.mapStatus || 'Still mapping… refresh the page if this stalls.', false);
  } catch (e) {
    setStatus('Webcam: ' + (e.message || e), false);
  }
}

$('#mapBatch').onclick = () => $('#batch').click();
$('#mapShot').onclick = () => $('#shot').click();
$('#mapSkip').onclick = () => mapAdvance();
$('#mapCancel').onclick = () => mapEnd(true);
$('#mapSave').onclick = () => mapSave();
$('#shot').onchange = ev => { if (ev.target.files[0]) mapGotFile(ev.target.files[0], S && S.mapPattern >= 0 ? S.mapPattern : MapUI.photos.length); ev.target.value = ''; };
$('#batch').onchange = ev => { mapBatch(ev.target.files); ev.target.value = ''; };
$('#thr').oninput = () => { $('#thrV').textContent = $('#thr').value; if (MapUI.photos.length) mapPreview(); };

async function mapBegin() {
  $('#mapUi').hidden = false;
  MapUI.photos = []; MapUI.mask = null; MapUI.fire = null;
  await api('/api/map', { action: 'start', frame: 0 });
  mapPrompt(0);
}
function mapPrompt(i) {
  const names = ['black (room + corners)', 'white (lit wall + corners)', 'checkerboard + corners'];
  $('#mapStep').textContent = 'Pattern ' + (i+1) + ' of 3: ' + names[i] + '. Fill the frame with the projection, keep the four colour corners visible, then take the photo.';
  $('#mapSave').hidden = true;
  $('#mapShot').disabled = false;
}
async function mapGotFile(file, frame) {
  const img = await Mapper.loadImage(file);
  MapUI.photos[frame] = { frame, img };
  setStatus('Got photo ' + (frame+1) + '/3', true);
  if (frame < 2) {
    await api('/api/map', { action: 'frame', frame: frame + 1 });
    mapPrompt(frame + 1);
  } else {
    await api('/api/map', { action: 'stop' });
    await mapPreview();
  }
}
async function mapAdvance() {
  const i = MapUI.photos.filter(Boolean).length;
  if (i < 3) { await api('/api/map', { action: 'frame', frame: i }); mapPrompt(i); }
  else await mapPreview();
}
async function mapBatch(files) {
  $('#mapUi').hidden = false;
  setStatus('Reading ' + files.length + ' photos…');
  const imgs = [];
  for (const f of files) imgs.push(await Mapper.loadImage(f));
  // classify by brightness / grid after finding corners
  const spec = await api('/api/map/spec');
  const sorted = await Mapper.classify(imgs, spec);
  MapUI.photos = sorted;
  await api('/api/map', { action: 'stop' });
  await mapPreview();
}
async function mapPreview() {
  const spec = await api('/api/map/spec');
  const have = MapUI.photos.filter(Boolean);
  if (have.length < 2) { setStatus('Need at least the black and white photos', false); return; }
  try {
    const r = await Mapper.build(have, spec, +$('#thr').value);
    MapUI.mask = r.mask; MapUI.fire = r.fireplace || MapUI.fire;
    Mapper.drawPreview($('#mapPrev'), r);
    if (MapUI.fire) Mapper.drawFire($('#mapPrev'), MapUI.fire);
    $('#mapSave').hidden = false;
    setStatus('Preview ready — adjust the threshold or drag a fireplace box, then save', true);
  } catch (e) { setStatus('Mapping: ' + e.message, false); }
}
async function mapSave() {
  if (!MapUI.mask) { setStatus('Nothing to save yet', false); return; }
  const png = Mapper.maskPng(MapUI.mask);
  await api('/api/scan', {
    source: 'phone', mask_png: png,
    fireplace: MapUI.fire ? [MapUI.fire.x0, MapUI.fire.y0, MapUI.fire.x1, MapUI.fire.y1] : undefined
  });
  await api('/api/map', { action: 'stop' });
  setStatus('Scan saved on the Astro', true);
  await refresh();
}
async function mapEnd(cancel) {
  await api('/api/map', { action: 'stop' });
  $('#mapUi').hidden = true;
  MapUI.photos = [];
  if (cancel) setStatus('Mapping cancelled');
}

/* fireplace drag on the preview */
(() => {
  const c = $('#mapPrev');
  let drag = null;
  function pos(ev) {
    const r = c.getBoundingClientRect(), t = ev.touches ? ev.touches[0] : ev;
    return { x: (t.clientX - r.left) / r.width, y: (t.clientY - r.top) / r.height };
  }
  function down(ev) { ev.preventDefault(); const p = pos(ev); drag = { x0:p.x, y0:p.y, x1:p.x, y1:p.y }; }
  function move(ev) { if (!drag) return; ev.preventDefault(); const p = pos(ev); drag.x1=p.x; drag.y1=p.y; MapUI.fire = { x0:Math.min(drag.x0,drag.x1), y0:Math.min(drag.y0,drag.y1), x1:Math.max(drag.x0,drag.x1), y1:Math.max(drag.y0,drag.y1) }; if (MapUI.mask) { Mapper.drawPreview(c, { preview: window._prevImg, mask: MapUI.mask, fireplace: MapUI.fire }); } }
  function up() { drag = null; }
  c.addEventListener('mousedown', down); c.addEventListener('mousemove', move); window.addEventListener('mouseup', up);
  c.addEventListener('touchstart', down, {passive:false}); c.addEventListener('touchmove', move, {passive:false}); c.addEventListener('touchend', up);
})();

refresh().catch(e => setStatus('Cannot reach the Astro: ' + e.message, false));
setInterval(() => { if (S) api('/api/state').then(s => { S.fps = s.fps; }).catch(() => {}); }, 4000);

$('#showQr').onclick = async () => {
  try { await api('/api/qr', {}); setStatus('QR codes are on the Astro for 20 seconds', true); }
  catch (e) { setStatus('Show QR: ' + (e.message || e), false); }
};
