/* Outline editor for Astro Lava, like the Pi's: the objects on the wall as shapes you can drag, add and delete.
   Shapes are polygons in projector space (0..1, y down). Saving sends them as a scene; the Astro fills them into
   its obstacle mask (ScanData.fromScene). The mapping photo, warped into projector space, is the background and is
   what Gemini looks at (through the Pi, with the Pi's key). */
const Outline = (() => {
  const W = 854, H = 480;
  let cv, ctx, bg = null, shapes = [], cur = -1, vtx = -1, drag = null, dirty = false, photo = null, scan = null;
  const COL = ['#ff9de0', '#7fdcff', '#ffe600', '#50ff50', '#ffa040', '#c8a0ff'];
  const $o = s => document.querySelector(s);

  /* ---- shapes from what the Astro has ---- */
  // a thick line (Pi line props: a rifle, a vine) as a polygon round it
  function lineToPoly(pts, width) {
    const w = Math.max(0.004, width || 0.01) / 2, P = pts.map(p => [p[0] * W, p[1] * H]), r = w * H;
    if (P.length < 2) return [];
    const left = [], right = [];
    for (let i = 0; i < P.length; i++) {
      const a = P[Math.max(0, i - 1)], b = P[Math.min(P.length - 1, i + 1)];
      const dx = b[0] - a[0], dy = b[1] - a[1], L = Math.hypot(dx, dy) || 1, nx = -dy / L * r, ny = dx / L * r;
      left.push([P[i][0] + nx, P[i][1] + ny]); right.push([P[i][0] - nx, P[i][1] - ny]);
    }
    return left.concat(right.reverse()).map(p => [p[0] / W, p[1] / H]);
  }
  function fromProp(p, i) {
    if (Array.isArray(p)) return p.length >= 3 ? { label: 'object ' + (i + 1), pts: p.map(q => [+q[0], +q[1]]) } : null;
    if (!p || !Array.isArray(p.points)) return null;
    const line = p.shape !== 'poly' || p.points.length < 3;
    const pts = line ? lineToPoly(p.points, p.width) : p.points.map(q => [+q[0], +q[1]]);
    return pts.length >= 3 ? { label: p.label || ((p.group || 'object') + ' ' + (i + 1)), pts } : null;
  }
  function fromScan(j) {
    const sc = j.scene || j, out = [];
    const objs = sc.objects || sc.props || [];
    objs.forEach((p, i) => { const s = fromProp(p, i); if (s) out.push(s); });
    if (Array.isArray(sc.rock) && sc.rock.length >= 3) out.unshift({ label: 'Bounding box (effects stay inside)', box: true, pts: sc.rock.map(q => [+q[0], +q[1]]) });
    return out;
  }

  /* ---- Suggest from scan: trace the saved mask into outlines ---- */
  async function traceMask() {
    const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('no mask')); i.src = '/api/scan/mask.png?t=' + Date.now(); });
    const S = 4, gw = Math.ceil(W / S), gh = Math.ceil(H / S);
    const c = document.createElement('canvas'); c.width = gw; c.height = gh;
    const g = c.getContext('2d', { willReadFrequently: true }); g.drawImage(img, 0, 0, gw, gh);
    const d = g.getImageData(0, 0, gw, gh).data, m = new Uint8Array(gw * gh);
    for (let i = 0; i < m.length; i++) m[i] = d[i * 4] > 127 ? 1 : 0;
    const lab = new Int32Array(gw * gh), out = [];
    let id = 0;
    for (let s0 = 0; s0 < m.length; s0++) {
      if (!m[s0] || lab[s0]) continue;
      id++; const st = [s0]; lab[s0] = id; let n = 0;
      while (st.length) {
        const q = st.pop(); n++; const x = q % gw, y = (q / gw) | 0;
        for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
          const xx = x + dx, yy = y + dy; if (xx < 0 || yy < 0 || xx >= gw || yy >= gh) continue;
          const r = yy * gw + xx; if (m[r] && !lab[r]) { lab[r] = id; st.push(r); }
        }
      }
      if (n < 25) continue;                                   // a speck
      const ring = trace(lab, gw, gh, s0, id);
      const simp = simplify(ring, 1.3);
      if (simp.length >= 3) out.push({ label: 'object ' + (out.length + 1), pts: simp.map(p => [Math.min(1, p[0] * S / W), Math.min(1, p[1] * S / H)]), n });
    }
    out.sort((a, b) => b.n - a.n);
    return out.slice(0, 30).map(({ pts }, i) => ({ label: 'object ' + (i + 1), pts }));
  }
  // Moore-neighbour boundary trace of one labelled region, starting at its first (top-left) cell
  function trace(lab, gw, gh, start, id) {
    const at = (x, y) => x >= 0 && y >= 0 && x < gw && y < gh && lab[y * gw + x] === id;
    const N = [[-1,0],[-1,-1],[0,-1],[1,-1],[1,0],[1,1],[0,1],[-1,1]];
    let x = start % gw, y = (start / gw) | 0, dir = 0;
    const sx = x, sy = y, pts = [[x + 0.5, y + 0.5]];
    for (let guard = 0; guard < gw * gh * 2; guard++) {
      let found = false;
      for (let k = 0; k < 8; k++) {
        const d = (dir + k) % 8, nx = x + N[d][0], ny = y + N[d][1];
        if (at(nx, ny)) { x = nx; y = ny; dir = (d + 6) % 8; found = true; break; }
      }
      if (!found || (x === sx && y === sy)) break;
      pts.push([x + 0.5, y + 0.5]);
    }
    return pts;
  }
  function simplify(pts, eps) {
    if (pts.length < 4) return pts;
    const dp = (a, b) => {
      let best = -1, bd = 0;
      const [x1, y1] = pts[a], [x2, y2] = pts[b], L = Math.hypot(x2 - x1, y2 - y1) || 1;
      for (let i = a + 1; i < b; i++) {
        const dd = Math.abs((y2 - y1) * pts[i][0] - (x2 - x1) * pts[i][1] + x2 * y1 - y2 * x1) / L;
        if (dd > bd) { bd = dd; best = i; }
      }
      return bd > eps ? dp(a, best).concat(dp(best, b).slice(1)) : [pts[a], pts[b]];
    };
    // split the closed ring at its farthest point from the start so both halves are open chains
    let far = 0, fd = 0;
    pts.forEach((p, i) => { const d = Math.hypot(p[0] - pts[0][0], p[1] - pts[0][1]); if (d > fd) { fd = d; far = i; } });
    const a = dp(0, far), b = dp(far, pts.length - 1);
    let r = a.concat(b.slice(1));
    if (r.length > 40) r = r.filter((p, i) => i % Math.ceil(r.length / 40) === 0);
    const l = r[r.length - 1];
    if (r.length > 3 && Math.hypot(l[0] - r[0][0], l[1] - r[0][1]) < eps * 2) r.pop();   // the ring's closing point
    return r;
  }

  /* ---- drawing and editing (same feel as the Pi's editor) ---- */
  const P = p => [p[0] * W, p[1] * H];
  function draw() {
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
    if (bg) { ctx.globalAlpha = photo ? 0.9 : 0.35; ctx.drawImage(bg, 0, 0, W, H); ctx.globalAlpha = 1; }
    shapes.forEach((x, i) => {
      const on = i === cur, pts = x.pts.map(P), col = x.box ? '#e8e8e8' : COL[i % COL.length];
      ctx.strokeStyle = ctx.fillStyle = col; ctx.lineJoin = 'round';
      ctx.globalAlpha = cur < 0 || on ? 1 : 0.5;
      ctx.beginPath(); pts.forEach((p, k) => k ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])); ctx.closePath();
      ctx.lineWidth = on ? 3 : 2; ctx.stroke();
      if (!x.box) { ctx.globalAlpha = on ? 0.35 : 0.2; ctx.fill(); }
      ctx.globalAlpha = 1;
      if (on) pts.forEach((p, k) => { ctx.beginPath(); ctx.arc(p[0], p[1], k === vtx ? 9 : 7, 0, 7);
        ctx.fillStyle = k === vtx ? '#fff' : col; ctx.fill(); ctx.strokeStyle = '#000'; ctx.lineWidth = 1.5; ctx.stroke(); });
    });
    buttons();
  }
  function fillList() {
    const sel = $o('#olShape');
    sel.innerHTML = '<option value=-1>Select a shape…</option>' +
      shapes.map((x, i) => `<option value=${i}${i === cur ? ' selected' : ''}>${x.label.replace(/</g, '&lt;')}</option>`).join('');
  }
  function buttons() {
    const x = shapes[cur];
    $o('#olDel').disabled = !x; $o('#olClear').disabled = !shapes.length;
    $o('#olAddPt').disabled = !x; $o('#olDelPt').disabled = !x || vtx < 0 || x.pts.length <= 3;
    $o('#olBox').disabled = shapes.some(s => s.box);
    $o('#olSave').disabled = !dirty; $o('#olUndo').disabled = !dirty;
    $o('#olGemini').disabled = !photo;
    $o('#olName').hidden = !x || x.box; if (x && !x.box) $o('#olName').value = x.label;
  }
  const changed = () => { dirty = true; $o('#olNote').textContent = ''; fillList(); draw(); };
  const scale = () => { const r = cv.getBoundingClientRect(); return [W / r.width, r]; };
  const at = e => { const [k, r] = scale(); return [(e.clientX - r.left) * k, (e.clientY - r.top) * k]; };
  function inside(p, pts) {
    let c = false;
    for (let i = 0, j = pts.length - 1; i < pts.length; j = i++)
      if ((pts[i][1] > p[1]) !== (pts[j][1] > p[1]) && p[0] < (pts[j][0] - pts[i][0]) * (p[1] - pts[i][1]) / (pts[j][1] - pts[i][1]) + pts[i][0]) c = !c;
    return c;
  }
  function hit(p) {   // the smallest shape containing p
    let best = -1, area = Infinity;
    shapes.forEach((x, i) => {
      const pts = x.pts.map(P); if (!inside(p, pts)) return;
      let a = 0; pts.forEach((q, k) => { const r = pts[(k + 1) % pts.length]; a += q[0] * r[1] - r[0] * q[1]; });
      if (Math.abs(a) < area) { area = Math.abs(a); best = i; }
    });
    return best;
  }
  function wire() {
    cv.addEventListener('pointerdown', e => {
      const p = at(e), tol = 18 * scale()[0];
      if (cur >= 0) {
        const k = shapes[cur].pts.map(P).findIndex(q => Math.hypot(q[0] - p[0], q[1] - p[1]) < tol);
        if (k >= 0) { vtx = k; drag = { mode: 'vtx', last: p }; cv.setPointerCapture(e.pointerId); draw(); return; }
      }
      const i = hit(p);
      if (i !== cur) { cur = i; vtx = -1; fillList(); }
      else if (i >= 0) { drag = { mode: 'all', last: p }; cv.setPointerCapture(e.pointerId); }
      draw();
    });
    cv.addEventListener('pointermove', e => {
      if (!drag || cur < 0) return;
      const p = at(e), dx = (p[0] - drag.last[0]) / W, dy = (p[1] - drag.last[1]) / H; drag.last = p;
      const cl = v => Math.max(0, Math.min(1, Math.round(v * 10000) / 10000));
      const mv = q => { q[0] = cl(q[0] + dx); q[1] = cl(q[1] + dy); };
      if (drag.mode === 'vtx') mv(shapes[cur].pts[vtx]); else shapes[cur].pts.forEach(mv);
      dirty = true; draw();
    });
    const up = () => { drag = null; };
    cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
    $o('#olShape').onchange = e => { cur = +e.target.value; vtx = -1; draw(); };
    $o('#olName').onchange = e => { const x = shapes[cur]; if (x) { x.label = e.target.value.trim() || x.label; changed(); } };
    $o('#olAdd').onclick = () => {
      shapes.push({ label: 'new shape', pts: [[0.42, 0.4], [0.58, 0.4], [0.58, 0.6], [0.42, 0.6]] });
      cur = shapes.length - 1; vtx = -1; changed();
    };
    $o('#olBox').onclick = () => {
      shapes.unshift({ label: 'Bounding box (effects stay inside)', box: true, pts: [[0.05, 0.05], [0.95, 0.05], [0.95, 0.95], [0.05, 0.95]] });
      cur = 0; vtx = -1; changed();
    };
    $o('#olDel').onclick = () => { if (shapes[cur]) { shapes.splice(cur, 1); cur = -1; vtx = -1; changed(); } };
    $o('#olClear').onclick = () => {
      if (!shapes.length || !confirm('Delete every shape? Nothing is saved until you press Save.')) return;
      shapes = []; cur = -1; vtx = -1; changed();
    };
    $o('#olAddPt').onclick = () => {
      const x = shapes[cur]; if (!x) return;
      const k = vtx >= 0 ? vtx : x.pts.length - 1, a = x.pts[k], b = x.pts[(k + 1) % x.pts.length];
      x.pts.splice(k + 1, 0, [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2]); vtx = k + 1; changed();
    };
    $o('#olDelPt').onclick = () => {
      const x = shapes[cur]; if (!x || vtx < 0 || x.pts.length <= 3) return;
      x.pts.splice(vtx, 1); vtx = Math.min(vtx, x.pts.length - 1); changed();
    };
    $o('#olSuggest').onclick = async () => {
      try {
        const got = await traceMask();
        if (!got.length) { setStatus('The scan has no objects to outline. Map the wall first.', false); return; }
        shapes = shapes.filter(s => s.box).concat(got); cur = -1; vtx = -1; changed();
        setStatus('Outlined ' + got.length + ' object' + (got.length > 1 ? 's' : '') + ' from the scan. Drag to fix, then Save.', true);
      } catch (e) { setStatus('Suggest: ' + (e.message || e), false); }
    };
    $o('#olGemini').onclick = async e => {
      if (!photo) return;
      if (!confirm('Send the mapping photo to Google Gemini (through the Pi, with its key) to find and name the objects? Free tier: Google may use the picture.')) return;
      const b = e.target; b.disabled = true; b.textContent = 'Looking…';
      try {
        const sg = await api('/api/gemini', { photo });
        if (sg.error) { setStatus(sg.error, false); return; }
        const got = (sg.props || []).map((p, i) => fromProp(p, i)).filter(Boolean);
        if (!got.length) { setStatus('Gemini found nothing to outline.', false); return; }
        shapes = shapes.filter(s => s.box).concat(got); cur = -1; vtx = -1; changed();
        setStatus((sg.notes || []).join(' · ') + ' · Drag to fix, then Save.', true);
      } catch (err) { setStatus('Gemini: ' + (err.message || err), false); }
      finally { b.textContent = 'Name objects with Gemini'; buttons(); }
    };
    $o('#olUndo').onclick = () => open(true);
    $o('#olSave').onclick = async () => {
      const box = shapes.find(s => s.box), objs = shapes.filter(s => !s.box);
      const r4 = v => Math.round(v * 10000) / 10000;
      const scene = {
        rock: box ? box.pts.map(p => p.map(r4)) : [],
        props: objs.map(s => s.pts.map(p => p.map(r4))),        // what ScanData.fromScene fills
        objects: objs.map(s => ({ label: s.label, shape: 'poly', points: s.pts.map(p => p.map(r4)) })),
      };
      try {
        await api('/api/scan', { scene, source: 'edited', photo: photo || undefined });
        dirty = false; draw(); setStatus('Outlines saved on the Astro', true);
        if (typeof refresh === 'function') refresh();
      } catch (e) { setStatus('Save: ' + (e.message || e), false); }
    };
  }

  let wired = false;
  async function open(force) {
    if (!cv) { cv = $o('#olCanvas'); ctx = cv.getContext('2d'); }
    if (!wired) { wire(); wired = true; }
    if (dirty && !force) { draw(); return; }
    try { scan = await api('/api/scan.json'); } catch (e) { scan = {}; }
    photo = (scan && scan.photo) || (window._mapPhoto || null);
    shapes = fromScan(scan || {}); cur = -1; vtx = -1; dirty = false;
    bg = await new Promise(res => {
      const i = new Image(); i.onload = () => res(i); i.onerror = () => res(null);
      i.src = photo || ('/api/scan/mask.png?t=' + Date.now());
    });
    fillList(); draw();
    $o('#olNote').textContent = shapes.length ? '' : (photo ? 'No outlines yet: try Suggest from scan or Name objects with Gemini.'
      : 'No outlines yet. Suggest from scan traces the saved map; Gemini needs a phone mapping photo first.');
  }
  window.addEventListener('beforeunload', e => { if (dirty) { e.preventDefault(); e.returnValue = ''; } });
  return { open, _trace: traceMask, _simplify: simplify };
})();
