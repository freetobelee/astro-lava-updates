// Astro Lava: TOBE TUBE's metaball wax (native/tube.c, public/tube.js) as one fragment shader.
// Every blob adds r^2/d^2 to a field; wax is where the field passes 1. Tones, rim and glint follow tube.c's
// inking, with the slope taken analytically instead of from a 160x120 grid. GLSL ES 1.00; the app prepends
// a header that maps TEX/FRAG for ES 3.00 when that context is available.
#define MAXB 16
uniform vec2 uRes;        // surface size in px
uniform float uAsp;       // picture aspect (w/h)
uniform vec4 uB[MAXB];    // blob x, y (picture units, y up, height 1), r^2
uniform int uN;           // blobs in use
uniform sampler2D uBase;  // static field: R,G = f/8 hi/lo bytes, B = inside-glass mask
uniform vec2 uTx;         // one base texel in uv
uniform vec3 uP0; uniform vec3 uP1; uniform vec3 uP2; uniform vec3 uP3; uniform vec3 uP4;
uniform float uBg;        // 0 = black glass (projector), 1 = TOBE TUBE's lit background
uniform int uNS;          // clock hands: 0..2 capsules
uniform vec4 uC0;         // capsule 0 start.xy, end.xy (picture units, y up)
uniform vec4 uC1;
uniform vec2 uCR;         // r^2 for each capsule

float sm(float a, float b, float x) { float t = clamp((x - a) / (b - a), 0.0, 1.0); return t * t * (3.0 - 2.0 * t); }
float dec(vec4 t) { return (t.r * 65280.0 + t.g * 255.0) * (8.0 / 65535.0); }

void main() {
  vec2 uv = gl_FragCoord.xy / uRes;
  vec2 p = vec2((uv.x - 0.5) * uAsp, uv.y - 0.5);
  vec4 bt = TEX(uBase, uv);
  float f = dec(bt);
  vec2 g = vec2(dec(TEX(uBase, uv + vec2(uTx.x, 0.0))) - dec(TEX(uBase, uv - vec2(uTx.x, 0.0))),
                dec(TEX(uBase, uv + vec2(0.0, uTx.y))) - dec(TEX(uBase, uv - vec2(0.0, uTx.y)))) / (2.0 * uTx * vec2(uAsp, 1.0));
  for (int k = 0; k < MAXB; k++) {
    if (k >= uN) break;
    vec2 d = p - uB[k].xy;
    float d2 = max(dot(d, d), 1e-5);
    float q = uB[k].z / d2;
    f += q;
    g -= (2.0 * q / d2) * d;
  }
  if (uNS > 0) {
    vec2 a = uC0.xy, b = uC0.zw, pa = p - a, ba = b - a;
    float h = clamp(dot(pa, ba) / max(dot(ba, ba), 1e-6), 0.0, 1.0);
    vec2 d = pa - ba * h; float d2 = max(dot(d, d), 1e-5); float q = uCR.x / d2;
    f += q; g -= (2.0 * q / d2) * d;
  }
  if (uNS > 1) {
    vec2 a = uC1.xy, b = uC1.zw, pa = p - a, ba = b - a;
    float h = clamp(dot(pa, ba) / max(dot(ba, ba), 1e-6), 0.0, 1.0);
    vec2 d = pa - ba * h; float d2 = max(dot(d, d), 1e-5); float q = uCR.y / d2;
    f += q; g -= (2.0 * q / d2) * d;
  }
  f = min(f, 200.0);
  float e1 = f + 1.0;
  vec2 de = g / (e1 * e1);

  float v = uBg * (0.26 + 0.07 * sm(0.6, -0.55, p.y) + 0.03 * sm(0.35, 0.0, abs(uv.x - 0.5))) + 0.12 * sm(0.45, 0.95, f);
  float ins = sm(0.95, 1.08, f);
  if (ins > 0.0) {
    float w = 0.74 + 0.2 * sm(1.0, 4.0, f);
    if (f < 2.2) {   // only the edge of the wax is lit: a rim on the lower left, a glint on the upper right
      float gx = 272.8 * de.x, gy = -272.8 * de.y, g2 = gx * gx + gy * gy;
      if (g2 > 4.0) {
        float gm = sqrt(g2), kk = sm(0.0, 1.0, gm / 900.0) / gm;
        float dr = (0.371 * gx - 0.928 * gy) * kk, ds = (-0.566 * gx + 0.824 * gy) * kk;
        if (dr > 0.0) w += 0.18 * (1.0 - sm(1.0, 2.2, f)) * dr * dr;
        if (ds > 0.0) { float s2 = ds * ds, s4 = s2 * s2, s8 = s4 * s4; w += 0.3 * (1.0 - sm(1.0, 1.8, f)) * s8 * s2; }
      }
    }
    v += ins * (w - v);
  }
  float x = clamp(v, 0.0, 1.0) * 4.0;
  vec3 c = mix(uP0, uP1, clamp(x, 0.0, 1.0));
  c = mix(c, uP2, clamp(x - 1.0, 0.0, 1.0));
  c = mix(c, uP3, clamp(x - 2.0, 0.0, 1.0));
  c = mix(c, uP4, clamp(x - 3.0, 0.0, 1.0));
  FRAG = vec4(c * bt.b, 1.0);
}
