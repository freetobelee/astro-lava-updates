
/* Phone-photo mapping for Astro Lava.
   Each photo is registered from the colour targets round the edge (eight on new apps, four on old ones); any four do.
   Objects are found in projector space three ways, each judged against the wall near it rather than the whole photo:
   much darker than the wall (white minus black), a different colour from the wall, or the checkerboard landing in the
   wrong place (it is off the wall plane).
   Heavy work stays in the phone browser so the Astro's 1 GB is untouched. */
const Mapper = (() => {
  const PW = 854, PH = 480;
  
  function loadImage(file) {
    return new Promise((res, rej) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => { URL.revokeObjectURL(url); res(img); };
      img.onerror = () => { URL.revokeObjectURL(url); rej(new Error('could not read photo')); };
      img.src = url;
    });
  }

  function canvasOf(img, maxSide) {
    let w = img.width, h = img.height;
    if (maxSide && Math.max(w, h) > maxSide) {
      const s = maxSide / Math.max(w, h); w = Math.round(w * s); h = Math.round(h * s);
    }
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    const g = c.getContext('2d', { willReadFrequently: true });
    g.drawImage(img, 0, 0, w, h);
    return { c, g, w, h, data: g.getImageData(0, 0, w, h).data, scaleX: img.width / w, scaleY: img.height / h };
  }

  function hueSat(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
    let h = 0;
    if (d > 1e-6) {
      if (max === r) h = ((g - b) / d) % 6;
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60; if (h < 0) h += 360;
    }
    const s = max === 0 ? 0 : d / max, v = max;
    return { h, s, v, lum: 0.3 * r + 0.59 * g + 0.11 * b };
  }
  function hueDist(a, b) { let d = Math.abs(a - b); return d > 180 ? 360 - d : d; }

  // The targets come from the Astro's spec: eight (the corners and the middle of each edge) on new apps, the four
  // corners on older ones, clockwise from top-left. Any four the phone can see are enough to line a photo up.
  const OLD_HUES = [180, 300, 60, 120];      // cyan, magenta, yellow, lime: the 4-corner pattern
  let SLOTS = slotsOf(null), CORNERS = SLOTS.map((s, i) => i);
  function slotsOf(spec) {
    if (spec && Array.isArray(spec.targets) && spec.targets.length >= 4)
      return spec.targets.map(t => ({ x: +t.x, y: +t.y, hue: +t.hue }));
    const cs = spec && spec.corners && spec.corners.length === 4 ? spec.corners
      : [{ x: 0.1, y: 0.1 }, { x: 0.9, y: 0.1 }, { x: 0.9, y: 0.9 }, { x: 0.1, y: 0.9 }];
    return cs.map((c, i) => ({ x: +c.x, y: +c.y, hue: c.hue != null ? +c.hue : OLD_HUES[i] }));
  }
  function useSpec(spec) {
    if (!spec) return;
    const s = slotsOf(spec);
    if (JSON.stringify(s) === JSON.stringify(SLOTS)) return;
    SLOTS = s;
    // which slots are the spec's corners (Hfrom lines photos up on those)
    const cs = spec.corners || [];
    CORNERS = cs.length === 4 ? cs.map(c => { let b = 0; s.forEach((t, i) => { if (Math.hypot(t.x - c.x, t.y - c.y) < Math.hypot(s[b].x - c.x, s[b].y - c.y)) b = i; }); return b; }) : [0, 1, 2, 3];
    cornerCache = new WeakMap();
  }
  function slotName(i) {
    const t = SLOTS[i], h = t.x < 0.3 ? 'left' : t.x > 0.7 ? 'right' : '', v = t.y < 0.3 ? 'top' : t.y > 0.7 ? 'bottom' : '';
    return v && h ? v + '-' + h : v || h;
  }

  let cornerCache = new WeakMap();
  /** The spec's four corners (TL, TR, BR, BL) in photo pixels, worked out from every target found, so a hidden
   *  corner is fine as long as four targets show. */
  function findCorners(img, spec) {
    useSpec(spec);
    let c = cornerCache.get(img);
    if (!c) {
      try { c = findCorners0(img); } catch (e) { c = { err: e }; }
      cornerCache.set(img, c);
    }
    if (c.err) throw c.err;
    return c.pts.map(p => Object.assign({}, p));
  }
  /** What was found in a photo: which targets were hidden, and whether Gemini helped. */
  function info(img) {
    const c = cornerCache.get(img);
    if (!c || !c.pts) return null;
    return { missing: c.missing.map(slotName), of: SLOTS.length, gemini: !!c.gemini, borrowed: !!c.realigned };
  }
  // The photos of one mapping are taken from about the same spot, so their targets land in about the same places.
  // Take the photo whose targets look most like targets as the reference, and re-pick any photo that failed or
  // disagrees with it, looking only near where the reference's targets are.
  function alignSet(imgs, spec) {
    useSpec(spec);
    const list = imgs.filter(Boolean);
    list.forEach(img => { try { findCorners(img); } catch (e) {} });
    let ref = null;
    for (const img of list) { const c = cornerCache.get(img); if (c.pts && (!ref || c.q > cornerCache.get(ref).q)) ref = img; }
    if (!ref) return;
    const R = cornerCache.get(ref), rn = R.pts.map(p => ({ x: p.x / ref.width, y: p.y / ref.height }));
    for (const img of list) {
      if (img === ref) continue;
      const c = cornerCache.get(img);
      const off = c.pts ? Math.max(...c.pts.map((p, i) => Math.hypot(p.x / img.width - rn[i].x, p.y / img.height - rn[i].y))) : 1;
      if (off < 0.06) continue;
      try { const c2 = findCorners0(img, { pts: R.all, synth: false }); c2.realigned = true; cornerCache.set(img, c2); continue; } catch (e) {}
      // still short of four: if at least three targets it does see sit where the reference has them (the phone
      // didn't move between photos), borrow the reference's spots for the hidden ones
      if (c.pts) continue;
      try {
        const c2 = findCorners0(img, { pts: R.all, synth: true });
        if (c2.real >= 3 && c2.priorOff < 0.006) { c2.realigned = true; cornerCache.set(img, c2); }
      } catch (e) {}
    }
  }
  // Only when the phone can't line a photo up itself: a small copy (768 px, ~60 KB) goes to Gemini through the Astro
  // and the Pi, which answers with rough target centres; the phone then fine-tunes them here as usual.
  // ask(dataUrl) -> [{x, y}] in 0..1. One call per failed photo, and none when the photo works.
  async function rescue(img, ask, spec) {
    useSpec(spec);
    try { findCorners(img); return { ok: true, used: false }; } catch (e) {}
    const small = canvasOf(img, 768);
    const pts = await ask(small.c.toDataURL('image/jpeg', 0.75));
    if (!Array.isArray(pts) || pts.length < 4) throw new Error('Gemini found ' + (pts ? pts.length : 0) + ' squares; it needs 4');
    const c = findCorners0(img, { pts: pts.slice(0, 12).map(p => ({ x: +p.x, y: +p.y })), synth: true, lax: true });
    c.gemini = true; cornerCache.set(img, c);
    return { ok: true, used: true };
  }
  function orderPts(q) {
    const mx = q.reduce((s, b) => s + b.x, 0) / q.length, my = q.reduce((s, b) => s + b.y, 0) / q.length;
    const r = q.slice().sort((a, b) => Math.atan2(a.y - my, a.x - mx) - Math.atan2(b.y - my, b.x - mx));
    let tl = 0; r.forEach((b, i) => { if (b.x + b.y < r[tl].x + r[tl].y) tl = i; });
    return r.slice(tl).concat(r.slice(0, tl));
  }
  // Least squares homography for 4 or more point pairs (exact for 4).
  function homographyLS(src, dst) {
    if (src.length === 4) return homography(src, dst);
    const N = Array.from({ length: 8 }, () => new Array(9).fill(0));
    for (let i = 0; i < src.length; i++) {
      const x = src[i].x, y = src[i].y, u = dst[i].x, v = dst[i].y;
      for (const [r, b] of [[[x, y, 1, 0, 0, 0, -u * x, -u * y], u], [[0, 0, 0, x, y, 1, -v * x, -v * y], v]])
        for (let a = 0; a < 8; a++) { for (let c = 0; c < 8; c++) N[a][c] += r[a] * r[c]; N[a][8] += r[a] * b; }
    }
    const h = solve8(N); h.push(1); return h;
  }
  // Warm room light makes a white wall read as yellow (and its white rings too). Balance on the brightest pale
  // pixels, which are the lit wall or the targets' white rings, so white comes out white.
  function whiteGain(src) {
    // The projector's white is the commonest colour among the bright pixels (the lit wall, the rings, the checker
    // squares). Taking the brightest pixels instead let a lamp shade set the balance, and then the projector's white
    // read as pale blue and the checker squares looked like coloured targets (Lee, 2026-11-20).
    const { data } = src, hist = new Uint32Array(256);
    const n = data.length / 4, step = Math.max(1, Math.floor(n / 60000));
    for (let i = 0; i < n; i += step) { const j = i * 4; hist[(0.3 * data[j] + 0.59 * data[j+1] + 0.11 * data[j+2]) | 0]++; }
    let acc = 0, cut = 255; const want = (n / step) * 0.08;
    while (cut > 0 && acc + hist[cut] < want) acc += hist[cut--];
    const B = 40, bins = new Uint32Array(B * B), sums = new Float64Array(B * B * 3);
    for (let i = 0; i < n; i += step) {
      const j = i * 4, R = data[j], G = data[j+1], Bl = data[j+2];
      if (0.3 * R + 0.59 * G + 0.11 * Bl < Math.max(cut, 40)) continue;
      const t = R + G + Bl + 1, bx = Math.min(B - 1, (R / t * B * 1.5) | 0), by = Math.min(B - 1, (G / t * B * 1.5) | 0), k = by * B + bx;
      bins[k]++; sums[k * 3] += R; sums[k * 3 + 1] += G; sums[k * 3 + 2] += Bl;
    }
    let best = -1, bc = 0;
    for (let y = 0; y < B; y++) for (let x = 0; x < B; x++) {
      let c = 0;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const xx = x + dx, yy = y + dy; if (xx >= 0 && yy >= 0 && xx < B && yy < B) c += bins[yy * B + xx]; }
      if (c > bc) { bc = c; best = y * B + x; }
    }
    if (best < 0 || bc < 20) return [1, 1, 1];
    let r = 0, g = 0, b = 0;
    const bx0 = best % B, by0 = (best / B) | 0;
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
      const xx = bx0 + dx, yy = by0 + dy; if (xx < 0 || yy < 0 || xx >= B || yy >= B) continue;
      const k = yy * B + xx; r += sums[k * 3]; g += sums[k * 3 + 1]; b += sums[k * 3 + 2];
    }
    const avg = (r + g + b) / 3;
    return [r, g, b].map(v => Math.min(2.5, Math.max(0.4, avg / v)));
  }
  function hsAt(src, i) {
    const k = src.gain, d = src.data;
    return hueSat(Math.min(255, d[i] * k[0]), Math.min(255, d[i+1] * k[1]), Math.min(255, d[i+2] * k[2]));
  }
  // Find the targets by their shape, not their exact colour: a coloured square inside a pale ring inside a dark
  // pad. The pattern's colours can arrive shifted (an effect's Hue/Saturation tinted it on older Astro apps: cyan came
  // out purple) or washed out by a dim or warm room, so the colours only have to keep their order round the wheel
  // after one common turn. Every set of four blobs is tried as every four targets in clockwise order; the guess
  // that lines up the most targets wins, checked hard (rings, sizes, colour order, an upright, sensible frame) so
  // a hidden target gives no map rather than a wrong one. prior {pts, synth}: points (0..1 of the photo) where
  // targets should be, from Gemini or the other photo; only blobs near them count, and with synth a point with no
  // blob near it stands in for one (Gemini saw a square the colours missed).
  function findCorners0(img, prior) {
    const src = canvasOf(img, 900);
    src.gain = whiteGain(src);
    const { w, h } = src;
    const cell = 3, gw = Math.ceil(w / cell), gh = Math.ceil(h / cell);
    const cnt = new Uint16Array(gw * gh), hx = new Float32Array(gw * gh), hy = new Float32Array(gw * gh);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const hs = hsAt(src, (y * w + x) * 4);
      if (hs.s < 0.16 || hs.v < 0.22) continue;
      const q = ((y / cell) | 0) * gw + ((x / cell) | 0), a = hs.h * Math.PI / 180;
      cnt[q]++; hx[q] += Math.cos(a) * hs.s; hy[q] += Math.sin(a) * hs.s;
    }
    const minCell = Math.max(2, (cell * cell) >> 1);
    const seen = new Uint8Array(gw * gh), blobs = [], stack = [];
    // neighbouring cells join only if their hue is close, so a target touching a colourful picture stays apart
    const hueOf = q => Math.atan2(hy[q], hx[q]);
    for (let s0 = 0; s0 < cnt.length; s0++) {
      if (cnt[s0] < minCell || seen[s0]) continue;
      stack.length = 0; stack.push(s0); seen[s0] = 1;
      let n = 0, px = 0, sx = 0, sy = 0, cx = 0, cy = 0, x0 = 1e9, y0 = 1e9, x1 = -1, y1 = -1;
      while (stack.length) {
        const q = stack.pop(), qx = q % gw, qy = (q / gw) | 0, wt = cnt[q];
        n++; px += wt; sx += (qx + 0.5) * wt; sy += (qy + 0.5) * wt; cx += hx[q]; cy += hy[q];
        if (qx < x0) x0 = qx; if (qx > x1) x1 = qx; if (qy < y0) y0 = qy; if (qy > y1) y1 = qy;
        const hq = hueOf(q);
        for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
          const nx = qx + dx, ny = qy + dy;
          if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue;
          const r = ny * gw + nx;
          if (seen[r] || cnt[r] < minCell) continue;
          let dh = Math.abs(hueOf(r) - hq); if (dh > Math.PI) dh = 2 * Math.PI - dh;
          if (dh > 0.6) continue;
          seen[r] = 1; stack.push(r);
        }
      }
      const bw = x1 - x0 + 1, bh = y1 - y0 + 1;
      if (n < 3) continue;                                  // a speck
      if (n > gw * gh * 0.06) continue;                     // a wash of colour, not a target
      if (Math.max(bw, bh) > 4 * Math.min(bw, bh)) continue; // a stripe
      if (n < bw * bh * 0.3) continue;                      // a scatter, not a solid patch
      const b = { x: sx / px * cell, y: sy / px * cell, n, hue: (Math.atan2(cy, cx) * 180 / Math.PI + 360) % 360,
                  sat: Math.hypot(cx, cy) / Math.max(1, px) };
      b.ring = ringScore(src, b, Math.sqrt(n) * cell / 2);
      b.side = Math.sqrt(n) * cell / w;                     // all photo geometry below is in units of photo width
      b.u = b.x / w; b.v = b.y / w;
      blobs.push(b);
    }
    const lax = !!(prior && prior.lax);    // Gemini's points: partly hidden squares may count
    const K = SLOTS.length;
    let cands;
    if (prior) {
      // only blobs near where a target should be; with synth, a stand-in where there is none
      const pp = prior.pts.map(p => ({ u: p.x, v: p.y * h / w }));
      const med = blobs.length ? blobs.map(b => b.side).sort((a, b) => a - b)[blobs.length >> 1] : 0.02;
      cands = [];
      for (const p of pp) {
        const near = blobs.filter(b => b.ring >= (lax ? 0.15 : 0.4) && Math.hypot(b.u - p.u, b.v - p.v) < 0.04)
          .sort((a, b) => Math.hypot(a.u - p.u, a.v - p.v) - Math.hypot(b.u - p.u, b.v - p.v));
        if (near.length) { if (!cands.includes(near[0])) cands.push(near[0]); }
        else if (prior.synth) cands.push({ u: p.u, v: p.v, x: p.u * w, y: p.v * w, n: (med * w / cell) ** 2, side: med, hue: NaN, ring: 0.5, synth: true });
      }
      cands = cands.slice(0, 12);
    } else {
      cands = blobs.filter(b => b.ring >= 0.4).sort((a, b) => b.n * (0.2 + b.ring) - a.n * (0.2 + a.ring)).slice(0, 12);
    }
    const devMax = lax ? 75 : 45;
    // the hue turn that best fits these (blob, slot) pairs, and how far the worst one is from it
    const hueDev = pairs => {
      let c = 0, s2 = 0, m = 0;
      for (const [b, j] of pairs) { if (!isFinite(b.hue)) continue; const d = (b.hue - SLOTS[j].hue) * Math.PI / 180; c += Math.cos(d); s2 += Math.sin(d); m++; }
      if (m < 2) return 0;
      const turn = Math.atan2(s2, c) * 180 / Math.PI;
      let worst = 0;
      for (const [b, j] of pairs) if (isFinite(b.hue)) worst = Math.max(worst, hueDist(b.hue, (SLOTS[j].hue + turn + 720) % 360));
      return worst;
    };
    const cross = (o, a, b) => (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);
    // H maps projector 0..1 to photo units. Is the frame it makes upright and believable, and which targets agree?
    const evaluate = (H, tolF) => {
      const F = [[0, 0], [1, 0], [1, 1], [0, 1]].map(([x, y]) => applyH(H, x, y));
      if (!F.every(p => isFinite(p.x) && isFinite(p.y))) return null;
      for (let i = 0; i < 4; i++) if (cross(F[i], F[(i + 1) % 4], F[(i + 2) % 4]) <= 0) return null;   // convex, clockwise
      const top = { x: F[1].x - F[0].x, y: F[1].y - F[0].y };
      if (top.x <= 0 || Math.abs(top.y) > top.x) return null;                                         // upright-ish
      const L = i => Math.hypot(F[(i + 1) % 4].x - F[i].x, F[(i + 1) % 4].y - F[i].y);
      const l = [L(0), L(1), L(2), L(3)];
      if (l[0] / l[2] > 2.2 || l[2] / l[0] > 2.2 || l[1] / l[3] > 2.2 || l[3] / l[1] > 2.2) return null;   // keystone, not a fold
      const span = (l[0] + l[2]) / 2;
      // a target's colour square is ~6.3% of the frame's width; allow a lot for angle and part-hidden squares
      const sMin = (lax ? 0.012 : 0.03) * span, sMax = 0.13 * span, tol = tolF * span;
      const used = new Set(), pairs = [];
      for (let j = 0; j < K; j++) {
        const p = applyH(H, SLOTS[j].x, SLOTS[j].y);
        let best = null, bd = tol;
        for (const b of cands) {
          if (used.has(b) || b.side < sMin || b.side > sMax) continue;
          const d = Math.hypot(b.u - p.x, b.v - p.y);
          if (d < bd) { bd = d; best = b; }
        }
        if (best) { used.add(best); pairs.push([best, j]); }
      }
      if (pairs.length < 4) return null;
      const ns = pairs.filter(([b]) => !b.synth).map(([b]) => b.n);
      if (ns.length >= 2 && Math.min(...ns) / Math.max(...ns) < (lax ? 0.12 : 0.3)) return null;
      // four is the fewest that fits at all, so then the colours must agree closely; with five or more the
      // geometry already vouches for the set and a camera's colour error (violet read as purple) is let through
      const dev = hueDev(pairs);
      if (dev > (pairs.length >= 5 ? devMax + 25 : devMax)) return null;
      return { pairs, dev, area: Math.abs(cross(F[0], F[1], F[2])) };
    };
    let best = null;
    const better = (e) => !best || e.pairs.length > best.pairs.length || (e.pairs.length === best.pairs.length &&
      (e.pairs.reduce((s, [b]) => s + b.ring, 0) - e.dev / 30 > best.pairs.reduce((s, [b]) => s + b.ring, 0) - best.dev / 30));
    const subsets = [];
    for (let a = 0; a < K; a++) for (let b = a + 1; b < K; b++) for (let c = b + 1; c < K; c++) for (let d = c + 1; d < K; d++) subsets.push([a, b, c, d]);
    const C = cands.length;
    for (let i = 0; i < C; i++) for (let j = i + 1; j < C; j++) for (let k = j + 1; k < C; k++) for (let m = k + 1; m < C; m++) {
      const q = orderPts([cands[i], cands[j], cands[k], cands[m]].map(b => Object.assign(Object.create(b), { x: b.u, y: b.v })));
      const ns = q.filter(b => !b.synth).map(b => b.n);
      if (ns.length >= 2 && Math.min(...ns) / Math.max(...ns) < (lax ? 0.12 : 0.3)) continue;
      for (const sub of subsets) for (let rot = 0; rot < 4; rot++) {
        const js = [0, 1, 2, 3].map(t => sub[(t + rot) % 4]);
        if (hueDev(q.map((b, t) => [b, js[t]])) > devMax + 25) continue;   // cheap: colours in the wrong order round
        let H;
        try { H = homography(js.map(t => SLOTS[t]), q); } catch (e) { continue; }
        const e = evaluate(H, lax ? 0.06 : 0.035);
        if (e && better(e)) best = e;
      }
    }
    if (!best) {
      const e = new Error(failHint(blobs, w, h));
      e.candidates = [blobs.slice(0, 10).map(b => Object.assign({ name: 'other' }, b))]; e.scale = [src.scaleX, src.scaleY]; throw e;
    }
    // fine-tune each target on a bigger copy, then fit all of them at once
    const big = canvasOf(img, 2400), k = big.w / w;
    big.gain = src.gain;
    const tuned = best.pairs.map(([b, j]) => {
      const r = b.synth ? { x: b.x * k, y: b.y * k } : refine(big, b.x * k, b.y * k, b.side * w / 2 * k, b.hue);
      return { j, u: r.x / big.w, v: r.y / big.w };
    });
    // a square that is partly hidden pulls its centre off: with more than four, drop the worst while it disagrees
    let Hf = homographyLS(tuned.map(t => SLOTS[t.j]), tuned.map(t => ({ x: t.u, y: t.v })));
    const span = Math.hypot(applyH(Hf, 1, 0).x - applyH(Hf, 0, 0).x, applyH(Hf, 1, 0).y - applyH(Hf, 0, 0).y);
    while (tuned.length > 4) {
      const res = tuned.map(t => { const p = applyH(Hf, SLOTS[t.j].x, SLOTS[t.j].y); return Math.hypot(p.x - t.u, p.y - t.v); });
      const worst = res.indexOf(Math.max(...res));
      if (res[worst] < span * 0.003) break;
      tuned.splice(worst, 1);
      Hf = homographyLS(tuned.map(t => SLOTS[t.j]), tuned.map(t => ({ x: t.u, y: t.v })));
    }
    const toPx = p => ({ x: p.x * img.width, y: p.y * img.width });
    const found = new Set(best.pairs.filter(([b]) => !b.synth).map(([, j]) => j));
    return {
      pts: CORNERS.map((j, i) => Object.assign(toPx(applyH(Hf, SLOTS[j].x, SLOTS[j].y)), { name: ['cyan', 'magenta', 'yellow', 'lime'][i] })),
      all: SLOTS.map(s => { const p = applyH(Hf, s.x, s.y); return { x: p.x, y: p.y * img.width / img.height }; }),
      found: tuned.map(t => toPx({ x: t.u, y: t.v })),
      missing: SLOTS.map((s, j) => j).filter(j => !found.has(j)),
      q: best.pairs.reduce((a, [b]) => a + b.ring, 0) / 4 + best.pairs.length,
      real: best.pairs.filter(([b]) => !b.synth).length,
      // how far the real targets are from the nearest prior point (did the phone move since the other photo?)
      priorOff: prior ? Math.max(0, ...tuned.filter(t => !best.pairs.find(([b, j]) => j === t.j)[0].synth)
        .map(t => Math.min(...prior.pts.map(p => Math.hypot(p.x - t.u, p.y * h / w - t.v))))) : 0,
    };
  }
  // Why a photo failed, in words that say what to do next.
  function failHint(blobs, w, h) {
    const t = blobs.filter(b => b.ring >= 0.4);
    const edge = t.filter(b => b.x < w * 0.03 || b.x > w * 0.97 || b.y < h * 0.03 || b.y > h * 0.97);
    const n = Math.min(t.length, SLOTS.length);
    if (edge.length) {
      const b = edge[0], side = b.x < w * 0.03 ? 'left' : b.x > w * 0.97 ? 'right' : b.y < h * 0.03 ? 'top' : 'bottom';
      return 'the picture runs off the ' + side + ' of the photo: step back so the whole projection fits';
    }
    if (n < 4) return 'could only see ' + n + ' of the ' + SLOTS.length + ' squares: step back, or move so less is in front of the picture';
    return "the squares it found don't line up: take it again from straight in front, with the whole projection in the photo";
  }
  // Each target is a colour square inside a white ring inside a black pad. Score how much a blob looks like that:
  // bright, pale samples round it at ~1.4x its half-size, darker ones at ~2.1x.
  function ringScore(src, b, hs) {
    const { w, h, data } = src;
    const at = (x, y) => { x = Math.round(x); y = Math.round(y); if (x < 0 || y < 0 || x >= w || y >= h) return null; return hsAt(src, (y * w + x) * 4); };
    let good = 0, n = 0;
    for (let a = 0; a < 16; a++) {
      const ca = Math.cos(a * Math.PI / 8), sa = Math.sin(a * Math.PI / 8);
      const f = Math.max(Math.abs(ca), Math.abs(sa));           // square, not round
      const ring = at(b.x + ca / f * hs * 1.4, b.y + sa / f * hs * 1.4), pad = at(b.x + ca / f * hs * 2.1, b.y + sa / f * hs * 2.1);
      n++;
      // the ring must be clearly paler than the square it holds: under warm room light the projector's white can
      // read as pale blue, and then a checker square (with white squares diagonally next to it) looked like a target
      // The pad is the projector's black, which on a lamp-lit wall is just the wall: a bit darker than the ring, or
      // more coloured than it (a warm wall), is enough.
      // Colour is judged against the ring, not absolutely: the room light can tint the projector's white.
      // The projector's black on a lit wall is just the wall, so the pad only has to be darker than the ring or
      // clearly more coloured than it (a lamp-lit wall reads orange).
      if (ring && pad && ring.s < (b.sat || 1) * 0.6 && ring.v > 0.3 &&
          (ring.lum > pad.lum * 1.15 || pad.s > ring.s + 0.25)) good++;
    }
    return good / n;
  }
  // Colour centroid of the square near (x, y) on the big copy.
  function refine(src, x, y, hs, hue) {
    if (!isFinite(hue)) return { x, y };
    const { w, h } = src, R = Math.ceil(hs * 1.25);
    const x0 = Math.max(0, Math.floor(x - R)), x1 = Math.min(w, Math.ceil(x + R)), y0 = Math.max(0, Math.floor(y - R)), y1 = Math.min(h, Math.ceil(y + R));
    let vmax = 0;
    for (let yy = y0; yy < y1; yy++) for (let xx = x0; xx < x1; xx++) {
      const q = hsAt(src, (yy * w + xx) * 4);
      if (q.s >= 0.16 && hueDist(q.h, hue) < 32 && q.v > vmax) vmax = q.v;
    }
    // a looser cut relative to the target's own brightness, so projector falloff doesn't eat one side of it
    let sx = 0, sy = 0, n = 0;
    for (let yy = y0; yy < y1; yy++) for (let xx = x0; xx < x1; xx++) {
      const q = hsAt(src, (yy * w + xx) * 4);
      if (q.s < 0.12 || q.v < vmax * 0.35 || hueDist(q.h, hue) >= 40) continue;
      sx += xx + 0.5; sy += yy + 0.5; n++;
    }
    return n > 8 ? { x: sx / n, y: sy / n } : { x, y };
  }

  /** A small copy of the photo with the corners it found (or the blobs it tried), for the mapping screen. */
  function drawFound(canvas, img, spec) {
    const g = canvas.getContext('2d');
    const s = Math.min(canvas.width / img.width, canvas.height / img.height);
    const dw = img.width * s, dh = img.height * s, ox = (canvas.width - dw) / 2, oy = (canvas.height - dh) / 2;
    g.fillStyle = '#000'; g.fillRect(0, 0, canvas.width, canvas.height);
    g.drawImage(img, ox, oy, dw, dh);
    const cols = { cyan: '#00ffff', magenta: '#ff00ff', yellow: '#ffff00', lime: '#00ff00', other: '#ffffff' };
    try {
      const pts = findCorners(img, spec);
      g.strokeStyle = '#fff'; g.lineWidth = 2; g.beginPath();
      pts.forEach((p, i) => { const x = ox + p.x * s, y = oy + p.y * s; i ? g.lineTo(x, y) : g.moveTo(x, y); });
      g.closePath(); g.stroke();
      const c = cornerCache.get(img);
      g.fillStyle = '#0f0';
      (c.found || []).forEach(p => { g.beginPath(); g.arc(ox + p.x * s, oy + p.y * s, 5, 0, 7); g.fill(); g.stroke(); });
      return { ok: true, info: info(img) };
    } catch (e) {
      (e.candidates || []).forEach(list => list.forEach(b => {
        g.strokeStyle = cols[b.name]; g.lineWidth = 2; g.beginPath();
        g.arc(ox + b.x * e.scale[0] * s, oy + b.y * e.scale[1] * s, 7, 0, 7); g.stroke();
      }));
      return { ok: false, error: e.message };
    }
  }

  // 3x3 homography: dest = H * src (photo -> projector)
  function homography(src, dst) {
    // DLT, 8 unknowns
    const A = [];
    for (let i = 0; i < 4; i++) {
      const x = src[i].x, y = src[i].y, u = dst[i].x, v = dst[i].y;
      A.push([ x, y, 1, 0, 0, 0, -u*x, -u*y, -u ]);
      A.push([ 0, 0, 0, x, y, 1, -v*x, -v*y, -v ]);
    }
    // solve A h = 0 with h[8]=1 via last column
    const M = A.map(r => r.slice(0, 8).concat(-r[8]));
    const h = solve8(M);
    h.push(1);
    return h;
  }
  function solve8(M) { // 8x9 augmented, gaussian
    const n = 8;
    for (let i = 0; i < n; i++) {
      let p = i;
      for (let r = i + 1; r < n; r++) if (Math.abs(M[r][i]) > Math.abs(M[p][i])) p = r;
      const tmp = M[i]; M[i] = M[p]; M[p] = tmp;
      const piv = M[i][i];
      if (Math.abs(piv) < 1e-12) throw new Error('could not fit the four corners (they may be in a line)');
      for (let c = i; c <= n; c++) M[i][c] /= piv;
      for (let r = 0; r < n; r++) if (r !== i) {
        const f = M[r][i];
        for (let c = i; c <= n; c++) M[r][c] -= f * M[i][c];
      }
    }
    return M.map(r => r[8]);
  }
  function invH(H) {
    const a=H[0],b=H[1],c=H[2],d=H[3],e=H[4],f=H[5],g=H[6],h=H[7],i=H[8];
    const A = e*i-f*h, B = c*h-b*i, C = b*f-c*e;
    const D = f*g-d*i, E = a*i-c*g, F = c*d-a*f;
    const G = d*h-e*g, Hh= b*g-a*h, I = a*e-b*d;
    const det = a*A + b*D + c*G;
    if (Math.abs(det) < 1e-12) throw new Error('bad homography');
    return [A,B,C,D,E,F,G,Hh,I].map(v => v / det);
  }
  function applyH(H, x, y) {
    const w = H[6]*x + H[7]*y + H[8], u = (H[0]*x + H[1]*y + H[2]) / w, v = (H[3]*x + H[4]*y + H[5]) / w;
    return { x:u, y:v };
  }

  function warp(img, H, dw, dh) {
    const src = canvasOf(img, 2000);
    const inv = invH(H);
    const out = new Float32Array(dw * dh); // luma
    const rgba = new Uint8ClampedArray(dw * dh * 4);
    const { w, h, data } = src;
    for (let y = 0; y < dh; y++) for (let x = 0; x < dw; x++) {
      const p = applyH(inv, x + 0.5, y + 0.5);
      // H maps full-size photo pixels; this copy may be scaled down (a 12 MP phone photo is, to 2000 px)
      const sx = p.x / src.scaleX, sy = p.y / src.scaleY;
      let lum = 0, r=0, g=0, b=0, ok = 0;
      if (sx >= 1 && sy >= 1 && sx < w-1 && sy < h-1) {
        const x0 = Math.floor(sx), y0 = Math.floor(sy), tx = sx - x0, ty = sy - y0;
        const i00 = (y0*w+x0)*4, i10 = i00+4, i01 = ((y0+1)*w+x0)*4, i11 = i01+4;
        const w00=(1-tx)*(1-ty), w10=tx*(1-ty), w01=(1-tx)*ty, w11=tx*ty;
        r = data[i00]*w00 + data[i10]*w10 + data[i01]*w01 + data[i11]*w11;
        g = data[i00+1]*w00 + data[i10+1]*w10 + data[i01+1]*w01 + data[i11+1]*w11;
        b = data[i00+2]*w00 + data[i10+2]*w10 + data[i01+2]*w01 + data[i11+2]*w11;
        lum = 0.3*r + 0.59*g + 0.11*b; ok = 1;
      }
      const i = y*dw+x;
      out[i] = ok ? lum : -1;
      rgba[i*4] = r; rgba[i*4+1] = g; rgba[i*4+2] = b; rgba[i*4+3] = ok ? 255 : 0;
    }
    return { luma: out, rgba, w: dw, h: dh };
  }

  function Hfrom(img, spec) {
    const found = findCorners(img, spec);
    const src = found.map(p => ({ x: p.x, y: p.y }));
    const dst = spec.corners.map(c => ({ x: c.x * PW, y: c.y * PH }));
    return homography(src, dst);
  }

  function classify(imgs, spec) {
    alignSet(imgs, spec);
    // Score each photo: mean luma of the warped interior, and checker energy
    const scored = [];
    for (const img of imgs) {
      let H;
      try { H = Hfrom(img, spec); }
      catch (e) { e.message = 'photo ' + (imgs.indexOf(img) + 1) + ': ' + e.message; throw e; }
      const sx = 214 / PW, sy = 120 / PH;  // a small copy of projector space: scale H down to it
      const Hs = H.slice(); for (let k = 0; k < 3; k++) { Hs[k] *= sx; Hs[3 + k] *= sy; }
      const w = warp(img, Hs, 214, 120); // cheap
      let sum = 0, n = 0, tog = 0;
      const m = 0.18, x0 = (m*214)|0, x1 = ((1-m)*214)|0, y0=(m*120)|0, y1=((1-m)*120)|0;
      for (let y=y0;y<y1;y++) for (let x=x0;x<x1;x++) {
        const v = w.luma[y*214+x]; if (v < 0) continue;
        sum += v; n++;
        const cell = (((x-x0)/((x1-x0)/8))|0) + (((y-y0)/((y1-y0)/5))|0);
        tog += (cell & 1) ? v : -v;
      }
      scored.push({ img, mean: n?sum/n:0, grid: Math.abs(tog), H });
    }
    if (scored.length < 2) throw new Error('need at least two photos (white and checker)');
    if (scored.length === 2) {                 // white + checker: the checker is the one with the pattern in it
      const [g, w] = scored.slice().sort((a, b) => b.grid / (b.mean || 1) - a.grid / (a.mean || 1));
      return [undefined, { frame: 1, img: w.img }, { frame: 2, img: g.img }];
    }
    const byMean = scored.slice().sort((a,b) => a.mean - b.mean);
    const black = byMean[0];
    const rest = byMean.slice(1);
    rest.sort((a,b) => b.grid - a.grid);
    const grid = rest.length > 1 && rest[0].grid > rest[rest.length-1].grid * 1.2 ? rest[0] : null;
    const white = rest.filter(s => s !== grid).sort((a,b) => b.mean - a.mean)[0] || rest[0];
    const out = [ { frame:0, img: black.img }, { frame:1, img: white.img } ];
    if (grid) out[2] = { frame:2, img: grid.img };
    return out;
  }

  // The wall level (white minus black) changes a lot across a photo: projector falloff, camera vignetting, a lamp.
  // So judge each pixel against the wall near it: the 80th percentile of its block, smoothed over neighbours.
  function localRef(d) {
    const B = 32, bw = Math.ceil(PW / B), bh = Math.ceil(PH / B), lv = new Float32Array(bw * bh).fill(NaN);
    const buf = [];
    for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) {
      buf.length = 0;
      for (let y = by * B; y < Math.min(PH, by * B + B); y++) for (let x = bx * B; x < Math.min(PW, bx * B + B); x++) {
        const v = d[y * PW + x]; if (v >= 0) buf.push(v);
      }
      if (buf.length < B * B * 0.3) continue;
      buf.sort((p, q) => p - q);
      lv[by * bw + bx] = buf[Math.floor(buf.length * 0.8)];
    }
    // fill gaps, then take the max of the 5x5 neighbourhood median so a block filled by one big object still
    // sees the wall around it
    const all = Array.from(lv).filter(v => !isNaN(v)).sort((p, q) => p - q);
    const glob = all.length ? all[Math.floor(all.length * 0.8)] : 30;
    const sm = new Float32Array(bw * bh);
    for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) {
      buf.length = 0;
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) {
        const x = bx + dx, y = by + dy; if (x < 0 || y < 0 || x >= bw || y >= bh) continue;
        const v = lv[y * bw + x]; if (!isNaN(v)) buf.push(v);
      }
      buf.sort((p, q) => p - q);
      let v = buf.length ? buf[Math.floor(buf.length * 0.75)] : glob;
      v = Math.max(v, glob * 0.25);       // never trust a block far darker than the wall as a whole
      sm[by * bw + bx] = Math.max(4, v);
    }
    const ref = new Float32Array(PW * PH);
    for (let y = 0; y < PH; y++) for (let x = 0; x < PW; x++) {
      const fx = Math.min(bw - 1, Math.max(0, (x + 0.5) / B - 0.5)), fy = Math.min(bh - 1, Math.max(0, (y + 0.5) / B - 0.5));
      const x0 = Math.floor(fx), y0 = Math.floor(fy), x1 = Math.min(bw - 1, x0 + 1), y1 = Math.min(bh - 1, y0 + 1), tx = fx - x0, ty = fy - y0;
      ref[y * PW + x] = (sm[y0*bw+x0] * (1-tx) + sm[y0*bw+x1] * tx) * (1-ty) + (sm[y1*bw+x0] * (1-tx) + sm[y1*bw+x1] * tx) * ty;
    }
    return { ref, glob };
  }

  // The wall's own colour near each pixel (chromaticity of the white photo), so a green plant on a beige wall
  // stands out even when it is about as bright as the wall.
  function localChroma(rgba, d, ref) {
    const B = 32, bw = Math.ceil(PW / B), bh = Math.ceil(PH / B);
    const cr = new Float32Array(bw * bh).fill(NaN), cg = new Float32Array(bw * bh).fill(NaN);
    const ar = [], ag = [];
    const med = a => { a.sort((p, q) => p - q); return a[a.length >> 1]; };
    for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) {
      ar.length = 0; ag.length = 0;
      for (let y = by * B; y < Math.min(PH, by * B + B); y++) for (let x = bx * B; x < Math.min(PW, bx * B + B); x++) {
        const i = y * PW + x; if (d[i] < ref[i] * 0.6) continue;
        const r = rgba[i*4], g = rgba[i*4+1], b = rgba[i*4+2], sum = r + g + b + 1;
        ar.push(r / sum); ag.push(g / sum);
      }
      if (ar.length < B * B * 0.2) continue;
      cr[by * bw + bx] = med(ar); cg[by * bw + bx] = med(ag);
    }
    const out = { r: new Float32Array(bw * bh), g: new Float32Array(bw * bh), B, bw };
    for (const [src, dst] of [[cr, out.r], [cg, out.g]]) {
      const all = Array.from(src).filter(v => !isNaN(v)); const glob = all.length ? med(all) : 1 / 3;
      for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) {
        const a = [];
        for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) {
          const x = bx + dx, y = by + dy; if (x < 0 || y < 0 || x >= bw || y >= bh) continue;
          const v = src[y * bw + x]; if (!isNaN(v)) a.push(v);
        }
        dst[by * bw + bx] = a.length ? med(a) : glob;
      }
    }
    return out;
  }

  // Drop blobs smaller than minA and fill enclosed holes smaller than minHole.
  function despeck(m, minA, minHole) {
    const lab = new Int32Array(PW * PH), st = [];
    for (const want of [255, 0]) {
      lab.fill(0); let id = 0;
      for (let s0 = 0; s0 < m.length; s0++) {
        if (m[s0] !== want || lab[s0]) continue;
        id++; st.length = 0; st.push(s0); lab[s0] = id;
        const cells = []; let edge = false;
        while (st.length) {
          const q = st.pop(); cells.push(q);
          const x = q % PW, y = (q / PW) | 0;
          if (x === 0 || y === 0 || x === PW - 1 || y === PH - 1) edge = true;
          if (x > 0 && !lab[q-1] && m[q-1] === want) { lab[q-1] = id; st.push(q-1); }
          if (x < PW-1 && !lab[q+1] && m[q+1] === want) { lab[q+1] = id; st.push(q+1); }
          if (y > 0 && !lab[q-PW] && m[q-PW] === want) { lab[q-PW] = id; st.push(q-PW); }
          if (y < PH-1 && !lab[q+PW] && m[q+PW] === want) { lab[q+PW] = id; st.push(q+PW); }
        }
        if (cells.length < (want === 255 ? minA : minHole) && (want === 255 || !edge)) for (const q of cells) m[q] = 255 - want;
      }
    }
  }

  function build(photos, spec, thr) {
    // Two photos do: white and checker (Lee). A black photo, if there is one, takes the room light out of the
    // brightness test; without it the white photo is judged on its own.
    const black = photos.find(p => p && p.frame === 0);
    const white = photos.find(p => p && p.frame === 1);
    const grid  = photos.find(p => p && p.frame === 2);
    if (!white) throw new Error('need the white photo');
    alignSet([black && black.img, white.img, grid && grid.img], spec);
    const H = (img, nm) => { try { return Hfrom(img, spec); } catch (e) { e.message = 'the ' + nm + ' photo: ' + e.message; throw e; } };
    const Hw = H(white.img, 'white'), Ww = warp(white.img, Hw, PW, PH);
    const Wb = black ? warp(black.img, H(black.img, 'black'), PW, PH) : { luma: new Float32Array(PW * PH), rgba: null };
    let Wg = null;
    if (grid) { try { Wg = warp(grid.img, Hfrom(grid.img, spec), PW, PH); } catch (e) { Wg = null; } }

    const N = PW * PH, d = new Float32Array(N);
    for (let i = 0; i < N; i++) { const a = Ww.luma[i], b = Wb.luma[i]; d[i] = (a < 0 || b < 0) ? -1 : Math.max(0, a - b); }
    const { ref, glob } = localRef(d);
    const T = thr / 40;                  // 18 → under 45% of the wall near it
    const ch = localChroma(Ww.rgba, d, ref), CT = 0.07 * 18 / thr;

    // the checkerboard, as Patterns.drawGrid draws it
    const gs = spec.grid || { cols: 8, rows: 5 }, cols = gs.cols || 8, rows = gs.rows || 5;
    const t = spec.target || 0.075, mg = spec.margin || 0.10, gm = mg + t + 0.02;
    const gx0 = gm * PW, gy0 = gm * PH, gcw = (1 - 2 * gm) * PW / cols, gch = (1 - 2 * gm) * PH / rows;
    const tol = 4;                       // pixels either side of a cell edge we don't judge (registration slop)
    useSpec(spec);
    const cs = SLOTS.map(t => [t.x, t.y]);

    const mask = new Uint8Array(N);
    for (let y = 0; y < PH; y++) for (let x = 0; x < PW; x++) {
      const i = y * PW + x;
      if (d[i] < 0) continue;
      let near = false;
      for (const c of cs) if (Math.abs(x/PW - c[0]) < t * 1.08 && Math.abs(y/PH - c[1]) < t * 1.08 * (PW/PH)) near = true;
      if (near) continue;                // the colour targets themselves are not objects
      const lvl = ref[i], r = d[i] / lvl;
      let obj = r < T;
      if (!obj && r > 0.15) {
        const bi = Math.min(ch.bw - 1, (x / ch.B) | 0) + ((y / ch.B) | 0) * ch.bw;
        const R = Ww.rgba[i*4], G = Ww.rgba[i*4+1], Bl = Ww.rgba[i*4+2], sum = R + G + Bl + 1;
        if (Math.abs(R / sum - ch.r[bi]) + Math.abs(G / sum - ch.g[bi]) > CT) obj = true;   // a different colour from the wall
      }
      if (!obj && Wg && Wg.luma[i] >= 0) {
        const u = (x + 0.5 - gx0) / gcw, v = (y + 0.5 - gy0) / gch;
        if (u >= 0 && v >= 0 && u < cols && v < rows) {
          const fu = (u - Math.floor(u)) * gcw, fv = (v - Math.floor(v)) * gch;
          if (fu > tol && fu < gcw - tol && fv > tol && fv < gch - tol) {
            const expectWhite = ((Math.floor(u) + Math.floor(v)) & 1) === 1;
            const rg = (Wg.luma[i] - Wb.luma[i]) / Math.max(d[i], lvl * 0.25);
            if (expectWhite ? rg < 0.45 : rg > 0.55) obj = true;   // the pattern landed somewhere else: off the wall
          }
        }
      }
      if (obj) mask[i] = 255;
    }
    // clean: close small gaps, open away thin noise, then drop specks and fill pinholes
    morph(mask, PW, PH, 2, true); morph(mask, PW, PH, 2, false);
    morph(mask, PW, PH, 1, false); morph(mask, PW, PH, 1, true);
    despeck(mask, Math.round(N * 0.002), Math.round(N * 0.006));

    const prev = new Uint8ClampedArray(N * 4);
    let cover = 0;
    for (let i = 0; i < N; i++) {
      const pr = Ww.rgba[i*4], pg = Ww.rgba[i*4+1], pb = Ww.rgba[i*4+2];
      prev[i*4] = pr; prev[i*4+1] = pg; prev[i*4+2] = pb; prev[i*4+3] = 255;
      if (d[i] < 0) { prev[i*4] = 40; prev[i*4+1] = 0; prev[i*4+2] = 0; }   // not in the photo
      if (mask[i]) { cover++; prev[i*4] = Math.min(255, pr + 90); prev[i*4+1] = pg * 0.7; prev[i*4+2] = Math.min(255, pb + 50); }
    }
    window._prevImg = { rgba: prev, w: PW, h: PH };
    return { mask, preview: window._prevImg, white: Ww, med: glob, T, cover: cover / N };
  }

  function morph(m, w, h, r, dilate) {
    const out = new Uint8Array(m);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      let v = dilate ? 0 : 255;
      for (let dy=-r; dy<=r; dy++) for (let dx=-r; dx<=r; dx++) {
        const xx=x+dx, yy=y+dy; if (xx<0||yy<0||xx>=w||yy>=h) continue;
        const p = m[yy*w+xx];
        if (dilate) { if (p) v=255; } else { if (!p) v=0; }
      }
      out[y*w+x] = v;
    }
    m.set(out);
  }

  function drawPreview(canvas, r) {
    const g = canvas.getContext('2d');
    const img = r.preview || r;
    const im = g.createImageData(PW, PH);
    im.data.set(img.rgba);
    const tmp = document.createElement('canvas'); tmp.width=PW; tmp.height=PH;
    tmp.getContext('2d').putImageData(im,0,0);
    g.drawImage(tmp, 0, 0, canvas.width, canvas.height);
  }
  /** The white photo, warped into projector space, as a JPEG data URL: the outline editor's background and
   *  what Gemini looks at. */
  function photoJpeg(Ww) {
    const c = document.createElement('canvas'); c.width = PW; c.height = PH;
    const g = c.getContext('2d'), im = g.createImageData(PW, PH);
    im.data.set(Ww.rgba);
    for (let i = 3; i < im.data.length; i += 4) im.data[i] = 255;
    g.putImageData(im, 0, 0);
    return c.toDataURL('image/jpeg', 0.8);
  }
  function maskPng(mask) {
    const c = document.createElement('canvas'); c.width=PW; c.height=PH;
    const g = c.getContext('2d');
    const im = g.createImageData(PW, PH);
    for (let i=0;i<PW*PH;i++) {
      const v = mask[i] ? 255 : 0;
      im.data[i*4]=v; im.data[i*4+1]=v; im.data[i*4+2]=v; im.data[i*4+3]=255;
    }
    g.putImageData(im,0,0);
    const data = c.toDataURL('image/png');
    return data.split(',')[1];
  }

  return { loadImage, findCorners, info, alignSet, rescue, photoJpeg, drawFound, classify, build, drawPreview, maskPng, Hfrom, homography, invH, applyH };
})();

/* Gemini, called by the Astro with its own key (Settings, This Astro), so it works without the Pi. The prompts and
   what is done with the answers live here, so they change with a content update. Only the Astro's app holds the key;
   with no key there, the Pi's Gemini is tried as before. */
const Gem = (() => {
  const OBJECTS = `This is a photo of a wall that a projector lights up (lava and other effects are projected on it).
List every distinct physical object on or in front of the wall that an effect could flow around or light up: for
example a picture frame, plants or branches, a lamp, a shelf, a jar, a TV, a rifle, a light switch.
Return a JSON list. For each object:
  "label": a short name, e.g. "picture frame", "fig branch", "floor lamp"
  "kind": one of "rifle", "plant", "jar", "bell", "fireplace", "frame", "other"
  "box_2d": [ymin, xmin, ymax, xmax], each 0-1000 relative to the image
  "shape": "line" for long thin things (branch, stem, vine, cable, strap, rifle), otherwise "outline"
  "line": for "line" shapes, 2 to 6 points [y, x] (0-1000) along its centre from one end to the other
  "polygon": for "outline" shapes, 4 to 30 points [y, x] (0-1000) going round its real silhouette closely
          (a rectangle is 4 points, exactly on its corners)
  "skip": true if it is too small or not worth an effect
Do not list the wall itself, the floor or the ceiling, or the projected picture's own squares. At most 20 objects.`;
  const CORNERS = `A projector shows a picture on a wall. Round its edge are up to eight small square targets (one near
each corner and one at the middle of each side): a coloured square inside a white square ring. Find the coloured
squares (their colours may look washed out or shifted, and some may be partly or wholly hidden).
Return a JSON list of exactly the targets you can see, each {"box_2d": [ymin, xmin, ymax, xmax]} of the coloured
square, 0-1000 relative to the image. Nothing else.`;

  async function post(path, body) {
    const r = await fetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    if (r.status === 404) return { error: 'missing' };          // an older Astro app without this route
    const t = await r.text();
    try { return JSON.parse(t); } catch (e) { return { error: t || ('HTTP ' + r.status) }; }
  }
  function parse(text) {
    let j = JSON.parse(text);
    if (j && !Array.isArray(j)) j = j.objects || j.targets || j.items || [];
    return Array.isArray(j) ? j.filter(o => o && typeof o === 'object') : [];
  }
  // the Astro's own key first; with none there (or an older app), the Pi's
  async function ask(prompt, models, budgetMs, photo, piPath) {
    const r = await post('/api/gemini/ask', { photo, prompt, models, budgetMs });
    if (r.error === 'nokey' || r.error === 'missing') {
      const p = await post(piPath, { photo });
      if (p.error === 'missing' || /reach the Pi|No Gemini key/.test(p.error || ''))
        return { error: 'no Gemini key yet: add one in Settings, This Astro' };
      return { pi: p };
    }
    if (r.error) return { error: r.error };
    try { return { list: parse(r.text) }; } catch (e) { return { error: "couldn't read Gemini's answer" }; }
  }

  const n1000 = v => Math.min(1, Math.max(0, +v / 1000));
  const pts = l => (Array.isArray(l) ? l : []).filter(q => Array.isArray(q) && q.length >= 2 && isFinite(q[0]) && isFinite(q[1]))
    .map(q => [Math.round(n1000(q[1]) * 1e4) / 1e4, Math.round(n1000(q[0]) * 1e4) / 1e4]);
  const box = o => {
    const b = o.box_2d; if (!Array.isArray(b) || b.length !== 4 || !b.every(v => isFinite(v))) return null;
    const [y0, x0, y1, x1] = b.map(n1000);
    return x1 - x0 < 0.004 || y1 - y0 < 0.004 ? null : [x0, y0, x1, y1];
  };
  /** Gemini's objects -> the outline editor's props (as the Pi's to_scene made them). */
  function toProps(objs) {
    const props = [], names = [], skipped = [];
    for (const o of objs) {
      const b = box(o); if (!b) continue;
      const label = String(o.label || o.kind || 'object').slice(0, 40), kind = String(o.kind || 'other').toLowerCase();
      if (o.skip === true) { skipped.push(label); continue; }
      names.push(label);
      const [x0, y0, x1, y1] = b;
      const line = String(o.shape || '').toLowerCase() === 'line' || kind === 'rifle';
      let poly = line ? [] : pts(o.polygon);
      if (!line && poly.length < 3) poly = [[x0, y0], [x1, y0], [x1, y1], [x0, y1]];
      if (poly.length >= 3) { props.push({ label, group: kind, shape: 'poly', points: poly, width: 0.01 }); continue; }
      let l = pts(o.line);
      if (l.length < 2) l = (x1 - x0) * 16 / 9 >= y1 - y0 ? [[x0, (y0 + y1) / 2], [x1, (y0 + y1) / 2]] : [[(x0 + x1) / 2, y0], [(x0 + x1) / 2, y1]];
      const short = Math.min((x1 - x0) * 854 / 480, y1 - y0);
      props.push({ label, group: kind, points: l, width: Math.round(Math.max(0.006, Math.min(0.06, short * 0.5)) * 1e4) / 1e4 });
    }
    const notes = ['Gemini found: ' + (names.join(', ') || 'nothing')];
    if (skipped.length) notes.push('Left out: ' + skipped.join(', '));
    return { props, notes };
  }

  /** The objects in the white map photo (already in projector space): {props, notes} or {error}. One call. */
  async function objects(photo) {
    const r = await ask(OBJECTS, ['gemini-2.5-flash', 'gemini-flash-latest'], 85000, photo, '/api/gemini');
    if (r.pi || r.error) return r.pi || r;
    return toProps(r.list);
  }
  /** Rough target centres (0..1) in a photo the phone couldn't line up: [{x, y}]. Cheapest model, small image. */
  async function corners(photo) {
    const r = await ask(CORNERS, ['gemini-2.5-flash-lite', 'gemini-2.5-flash'], 40000, photo, '/api/gemini-corners');
    if (r.error) throw new Error(r.error);
    if (r.pi) { if (r.pi.error) throw new Error(r.pi.error); return r.pi.points || []; }
    return r.list.map(box).filter(Boolean).map(([x0, y0, x1, y1]) => ({ x: (x0 + x1) / 2, y: (y0 + y1) / 2 })).slice(0, 12);
  }
  return { objects, corners, toProps };
})();
