
/* Phone-photo mapping for Astro Lava.
   Each photo is registered from the four colour corner targets (handheld shots do not line up on their own).
   The object mask is the difference between the white and black frames in projector space, plus a checkerboard residual when that photo is present.
   Heavy work stays in the phone browser so the Astro's 1 GB is untouched. */
const Mapper = (() => {
  const PW = 854, PH = 480;
  const HUES = { cyan: 180, magenta: 300, yellow: 60, lime: 120 };

  function loadImage(file) {
    return new Promise((res, rej) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => { URL.revokeObjectURL(url); res(img); };
      img.onerror = () => { URL.revokeObjectURL(url); rej(new Error('could not read photo')); };
      img.src = url;
    });
  }

  function canvasOf(img, maxSide) {
    let w = img.width, h = img.height;
    if (maxSide && Math.max(w, h) > maxSide) {
      const s = maxSide / Math.max(w, h); w = Math.round(w * s); h = Math.round(h * s);
    }
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    const g = c.getContext('2d', { willReadFrequently: true });
    g.drawImage(img, 0, 0, w, h);
    return { c, g, w, h, data: g.getImageData(0, 0, w, h).data, scaleX: img.width / w, scaleY: img.height / h };
  }

  function hueSat(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
    let h = 0;
    if (d > 1e-6) {
      if (max === r) h = ((g - b) / d) % 6;
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60; if (h < 0) h += 360;
    }
    const s = max === 0 ? 0 : d / max, v = max;
    return { h, s, v, lum: 0.3 * r + 0.59 * g + 0.11 * b };
  }
  function hueDist(a, b) { let d = Math.abs(a - b); return d > 180 ? 360 - d : d; }

  function findCorners(img, spec) {
    const src = canvasOf(img, 1400);
    const { w, h, data } = src;
    const names = ['cyan', 'magenta', 'yellow', 'lime'];
    const buckets = names.map(() => []);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      const hs = hueSat(data[i], data[i+1], data[i+2]);
      if (hs.s < 0.35 || hs.v < 0.35) continue;
      let best = -1, bd = 40;
      for (let k = 0; k < 4; k++) {
        const d = hueDist(hs.h, HUES[names[k]]);
        if (d < bd) { bd = d; best = k; }
      }
      if (best >= 0 && bd < 35) buckets[best].push(x, y);
    }
    const pts = [];
    for (let k = 0; k < 4; k++) {
      const arr = buckets[k];
      if (arr.length < 20) throw new Error('could not find the ' + names[k] + ' corner — keep all four colour targets in the frame');
      // centroid of the densest region: 2-D histogram peak, then mean of nearby points
      const bin = 16, gw = Math.ceil(w / bin), gh = Math.ceil(h / bin);
      const hist = new Uint32Array(gw * gh);
      for (let i = 0; i < arr.length; i += 2) hist[((arr[i+1] / bin) | 0) * gw + ((arr[i] / bin) | 0)]++;
      let best = 0, bx = 0, by = 0;
      for (let i = 0; i < hist.length; i++) if (hist[i] > best) { best = hist[i]; bx = i % gw; by = (i / gw) | 0; }
      let sx = 0, sy = 0, n = 0;
      const cx0 = (bx + 0.5) * bin, cy0 = (by + 0.5) * bin, rad = bin * 3;
      for (let i = 0; i < arr.length; i += 2) {
        const dx = arr[i] - cx0, dy = arr[i+1] - cy0;
        if (dx*dx + dy*dy < rad*rad) { sx += arr[i]; sy += arr[i+1]; n++; }
      }
      if (n < 8) throw new Error('weak ' + names[k] + ' corner');
      pts.push({ x: (sx / n) * src.scaleX, y: (sy / n) * src.scaleY, name: names[k] });
    }
    return pts; // TL, TR, BR, BL in photo pixels (same order as spec.corners)
  }

  // 3x3 homography: dest = H * src (photo -> projector)
  function homography(src, dst) {
    // DLT, 8 unknowns
    const A = [];
    for (let i = 0; i < 4; i++) {
      const x = src[i].x, y = src[i].y, u = dst[i].x, v = dst[i].y;
      A.push([ x, y, 1, 0, 0, 0, -u*x, -u*y, -u ]);
      A.push([ 0, 0, 0, x, y, 1, -v*x, -v*y, -v ]);
    }
    // solve A h = 0 with h[8]=1 via last column
    const M = A.map(r => r.slice(0, 8).concat(-r[8]));
    const h = solve8(M);
    h.push(1);
    return h;
  }
  function solve8(M) { // 8x9 augmented, gaussian
    const n = 8;
    for (let i = 0; i < n; i++) {
      let p = i;
      for (let r = i + 1; r < n; r++) if (Math.abs(M[r][i]) > Math.abs(M[p][i])) p = r;
      const tmp = M[i]; M[i] = M[p]; M[p] = tmp;
      const piv = M[i][i];
      if (Math.abs(piv) < 1e-12) throw new Error('could not fit the four corners (they may be in a line)');
      for (let c = i; c <= n; c++) M[i][c] /= piv;
      for (let r = 0; r < n; r++) if (r !== i) {
        const f = M[r][i];
        for (let c = i; c <= n; c++) M[r][c] -= f * M[i][c];
      }
    }
    return M.map(r => r[8]);
  }
  function invH(H) {
    const a=H[0],b=H[1],c=H[2],d=H[3],e=H[4],f=H[5],g=H[6],h=H[7],i=H[8];
    const A = e*i-f*h, B = c*h-b*i, C = b*f-c*e;
    const D = f*g-d*i, E = a*i-c*g, F = c*d-a*f;
    const G = d*h-e*g, Hh= b*g-a*h, I = a*e-b*d;
    const det = a*A + b*D + c*G;
    if (Math.abs(det) < 1e-12) throw new Error('bad homography');
    return [A,B,C,D,E,F,G,Hh,I].map(v => v / det);
  }
  function applyH(H, x, y) {
    const w = H[6]*x + H[7]*y + H[8], u = (H[0]*x + H[1]*y + H[2]) / w, v = (H[3]*x + H[4]*y + H[5]) / w;
    return { x:u, y:v };
  }

  function warp(img, H, dw, dh) {
    const src = canvasOf(img, 2000);
    const inv = invH(H);
    const out = new Float32Array(dw * dh); // luma
    const rgba = new Uint8ClampedArray(dw * dh * 4);
    const { w, h, data } = src;
    for (let y = 0; y < dh; y++) for (let x = 0; x < dw; x++) {
      const p = applyH(inv, x + 0.5, y + 0.5);
      const sx = p.x, sy = p.y;
      let lum = 0, r=0, g=0, b=0, ok = 0;
      if (sx >= 1 && sy >= 1 && sx < w-1 && sy < h-1) {
        const x0 = Math.floor(sx), y0 = Math.floor(sy), tx = sx - x0, ty = sy - y0;
        const i00 = (y0*w+x0)*4, i10 = i00+4, i01 = ((y0+1)*w+x0)*4, i11 = i01+4;
        const w00=(1-tx)*(1-ty), w10=tx*(1-ty), w01=(1-tx)*ty, w11=tx*ty;
        r = data[i00]*w00 + data[i10]*w10 + data[i01]*w01 + data[i11]*w11;
        g = data[i00+1]*w00 + data[i10+1]*w10 + data[i01+1]*w01 + data[i11+1]*w11;
        b = data[i00+2]*w00 + data[i10+2]*w10 + data[i01+2]*w01 + data[i11+2]*w11;
        lum = 0.3*r + 0.59*g + 0.11*b; ok = 1;
      }
      const i = y*dw+x;
      out[i] = ok ? lum : -1;
      rgba[i*4] = r; rgba[i*4+1] = g; rgba[i*4+2] = b; rgba[i*4+3] = ok ? 255 : 0;
    }
    return { luma: out, rgba, w: dw, h: dh };
  }

  function Hfrom(img, spec) {
    const found = findCorners(img, spec);
    const src = found.map(p => ({ x: p.x, y: p.y }));
    const dst = spec.corners.map(c => ({ x: c.x * PW, y: c.y * PH }));
    return homography(src, dst);
  }

  function classify(imgs, spec) {
    // Score each photo: mean luma of the warped interior, and checker energy
    const scored = [];
    for (const img of imgs) {
      const H = Hfrom(img, spec);
      const w = warp(img, H, 214, 120); // cheap
      let sum = 0, n = 0, tog = 0;
      const m = 0.18, x0 = (m*214)|0, x1 = ((1-m)*214)|0, y0=(m*120)|0, y1=((1-m)*120)|0;
      for (let y=y0;y<y1;y++) for (let x=x0;x<x1;x++) {
        const v = w.luma[y*214+x]; if (v < 0) continue;
        sum += v; n++;
        const cell = (((x-x0)/((x1-x0)/8))|0) + (((y-y0)/((y1-y0)/5))|0);
        tog += (cell & 1) ? v : -v;
      }
      scored.push({ img, mean: n?sum/n:0, grid: Math.abs(tog), H });
    }
    if (scored.length < 2) throw new Error('need at least two photos (black and white)');
    const byMean = scored.slice().sort((a,b) => a.mean - b.mean);
    const black = byMean[0];
    const rest = byMean.slice(1);
    rest.sort((a,b) => b.grid - a.grid);
    const grid = rest.length > 1 && rest[0].grid > rest[rest.length-1].grid * 1.2 ? rest[0] : null;
    const white = rest.filter(s => s !== grid).sort((a,b) => b.mean - a.mean)[0] || rest[0];
    const out = [ { frame:0, img: black.img }, { frame:1, img: white.img } ];
    if (grid) out[2] = { frame:2, img: grid.img };
    return out;
  }

  function build(photos, spec, thr) {
    const black = photos.find(p => p && p.frame === 0) || photos[0];
    const white = photos.find(p => p && p.frame === 1) || photos[1];
    const grid  = photos.find(p => p && p.frame === 2);
    if (!black || !white) throw new Error('need the black and white photos');
    const Hb = Hfrom(black.img, spec), Hw = Hfrom(white.img, spec);
    const Wb = warp(black.img, Hb, PW, PH), Ww = warp(white.img, Hw, PW, PH);
    let Wg = null;
    if (grid) { try { Wg = warp(grid.img, Hfrom(grid.img, spec), PW, PH); } catch (e) { Wg = null; } }

    const mask = new Uint8Array(PW * PH);
    const prev = new Uint8ClampedArray(PW * PH * 4);
    // wall level from the brighter frame
    const diffs = [];
    const mgn = 0.14;
    for (let y = 0; y < PH; y++) for (let x = 0; x < PW; x++) {
      const i = y*PW+x;
      const a = Ww.luma[i], b = Wb.luma[i];
      if (a < 0 || b < 0) continue;
      const nx = x/PW, ny = y/PH;
      if (nx < mgn || nx > 1-mgn || ny < mgn || ny > 1-mgn) continue;
      diffs.push(Math.max(0, a - b));
    }
    diffs.sort((a,b)=>a-b);
    const med = diffs[diffs.length>>1] || 30;
    const T = med * (thr / 40);         // thr 18 ~ a bit below the wall
    const coverT = Math.max(6, med * 0.15);

    for (let y = 0; y < PH; y++) for (let x = 0; x < PW; x++) {
      const i = y*PW+x;
      const a = Ww.luma[i], b = Wb.luma[i];
      const d = (a < 0 || b < 0) ? -1 : a - b;
      const covered = d >= coverT;
      let obj = 0;
      if (covered && d < T) obj = 1;
      if (Wg && a >= 0) {
        // expected checker (inner), residual when a white cell is dark or a black cell is bright
        const nx = x/PW, ny = y/PH, inn = 0.20;
        if (nx>inn && nx<1-inn && ny>inn && ny<1-inn) {
          const cols=8, rows=5;
          const u = (nx-inn)/(1-2*inn), v = (ny-inn)/(1-2*inn);
          const ci = Math.min(cols-1, Math.floor(u*cols)), cj = Math.min(rows-1, Math.floor(v*rows));
          const expectWhite = ((ci+cj)&1)===1;
          const gl = Wg.luma[i];
          if (gl >= 0) {
            if (expectWhite && gl < med * 0.45) obj = 1;
          }
        }
      }
      // corners themselves are not objects
      const t = spec.target || 0.075, m = spec.margin || 0.10;
      const cs = [[m,m],[1-m,m],[1-m,1-m],[m,1-m]];
      for (const c of cs) if (Math.abs(x/PW-c[0]) < t*1.2 && Math.abs(y/PH-c[1]) < t*1.2*(PW/PH)) obj = 0;
      mask[i] = obj ? 255 : 0;
      const pr = Ww.rgba[i*4], pg = Ww.rgba[i*4+1], pb = Ww.rgba[i*4+2];
      prev[i*4] = pr; prev[i*4+1] = pg; prev[i*4+2] = pb; prev[i*4+3] = 255;
      if (obj) { prev[i*4] = Math.min(255, pr + 80); prev[i*4+2] = Math.min(255, pb + 40); }
    }
    // clean: close then open, drop specks
    morph(mask, PW, PH, 2, true); morph(mask, PW, PH, 1, false);
    window._prevImg = { rgba: prev, w: PW, h: PH };
    return { mask, preview: window._prevImg, med, T };
  }

  function morph(m, w, h, r, dilate) {
    const out = new Uint8Array(m);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      let v = dilate ? 0 : 255;
      for (let dy=-r; dy<=r; dy++) for (let dx=-r; dx<=r; dx++) {
        const xx=x+dx, yy=y+dy; if (xx<0||yy<0||xx>=w||yy>=h) continue;
        const p = m[yy*w+xx];
        if (dilate) { if (p) v=255; } else { if (!p) v=0; }
      }
      out[y*w+x] = v;
    }
    m.set(out);
  }

  function drawPreview(canvas, r) {
    const g = canvas.getContext('2d');
    const img = r.preview || r;
    const im = g.createImageData(PW, PH);
    im.data.set(img.rgba);
    const tmp = document.createElement('canvas'); tmp.width=PW; tmp.height=PH;
    tmp.getContext('2d').putImageData(im,0,0);
    g.drawImage(tmp, 0, 0, canvas.width, canvas.height);
  }
  function maskPng(mask) {
    const c = document.createElement('canvas'); c.width=PW; c.height=PH;
    const g = c.getContext('2d');
    const im = g.createImageData(PW, PH);
    for (let i=0;i<PW*PH;i++) {
      const v = mask[i] ? 255 : 0;
      im.data[i*4]=v; im.data[i*4+1]=v; im.data[i*4+2]=v; im.data[i*4+3]=255;
    }
    g.putImageData(im,0,0);
    const data = c.toDataURL('image/png');
    return data.split(',')[1];
  }

  return { loadImage, findCorners, classify, build, drawPreview, maskPng, Hfrom, homography, invH, applyH };
})();
