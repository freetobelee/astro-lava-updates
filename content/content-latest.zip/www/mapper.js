
/* Phone-photo mapping for Astro Lava.
   Each photo is registered from the four colour corner targets (handheld shots do not line up on their own).
   Objects are found in projector space three ways, each judged against the wall near it rather than the whole photo:
   much darker than the wall (white minus black), a different colour from the wall, or the checkerboard landing in the
   wrong place (it is off the wall plane).
   Heavy work stays in the phone browser so the Astro's 1 GB is untouched. */
const Mapper = (() => {
  const PW = 854, PH = 480;
  const HUES = { cyan: 180, magenta: 300, yellow: 60, lime: 120 };

  function loadImage(file) {
    return new Promise((res, rej) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => { URL.revokeObjectURL(url); res(img); };
      img.onerror = () => { URL.revokeObjectURL(url); rej(new Error('could not read photo')); };
      img.src = url;
    });
  }

  function canvasOf(img, maxSide) {
    let w = img.width, h = img.height;
    if (maxSide && Math.max(w, h) > maxSide) {
      const s = maxSide / Math.max(w, h); w = Math.round(w * s); h = Math.round(h * s);
    }
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    const g = c.getContext('2d', { willReadFrequently: true });
    g.drawImage(img, 0, 0, w, h);
    return { c, g, w, h, data: g.getImageData(0, 0, w, h).data, scaleX: img.width / w, scaleY: img.height / h };
  }

  function hueSat(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
    let h = 0;
    if (d > 1e-6) {
      if (max === r) h = ((g - b) / d) % 6;
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60; if (h < 0) h += 360;
    }
    const s = max === 0 ? 0 : d / max, v = max;
    return { h, s, v, lum: 0.3 * r + 0.59 * g + 0.11 * b };
  }
  function hueDist(a, b) { let d = Math.abs(a - b); return d > 180 ? 360 - d : d; }

  // The four corner targets: colour blobs (cyan TL, magenta TR, yellow BR, lime BL). A photo can hold plenty of
  // other colour (a warm-lit wall reads as yellow, plants as lime, a lamp...), so instead of the biggest patch of
  // each colour, find every compact blob of each colour and pick the one-of-each set that makes the biggest
  // convex quadrilateral in the right order round. Returns TL, TR, BR, BL in photo pixels.
  const cornerCache = new WeakMap();
  function findCorners(img, spec) {
    let c = cornerCache.get(img);
    if (!c) {
      try { c = { pts: findCorners0(img) }; } catch (e) { c = { err: e }; }
      cornerCache.set(img, c);
    }
    if (c.err) throw c.err;
    return c.pts.map(p => Object.assign({}, p));
  }
  // Warm room light makes a white wall read as yellow (and its white rings too). Balance on the brightest pale
  // pixels, which are the lit wall or the targets' white rings, so white comes out white.
  function whiteGain(src) {
    const { data } = src, hist = new Uint32Array(256);
    const n = data.length / 4, step = Math.max(1, Math.floor(n / 60000));
    for (let i = 0; i < n; i += step) { const j = i * 4; hist[(0.3 * data[j] + 0.59 * data[j+1] + 0.11 * data[j+2]) | 0]++; }
    let acc = 0, cut = 255; const want = (n / step) * 0.08;
    while (cut > 0 && acc + hist[cut] < want) acc += hist[cut--];
    let r = 0, g = 0, b = 0, m = 0;
    for (let i = 0; i < n; i += step) {
      const j = i * 4, R = data[j], G = data[j+1], B = data[j+2];
      if (0.3 * R + 0.59 * G + 0.11 * B < cut) continue;
      const mx = Math.max(R, G, B), mn = Math.min(R, G, B);
      if (mx === 0 || (mx - mn) / mx > 0.45) continue;          // a colour target, not white
      r += R; g += G; b += B; m++;
    }
    if (m < 20) return [1, 1, 1];
    const avg = (r + g + b) / 3 / m;
    return [r, g, b].map(v => Math.min(2.5, Math.max(0.4, avg / (v / m))));
  }
  function hsAt(src, i) {
    const k = src.gain, d = src.data;
    return hueSat(Math.min(255, d[i] * k[0]), Math.min(255, d[i+1] * k[1]), Math.min(255, d[i+2] * k[2]));
  }
  function findCorners0(img) {
    const src = canvasOf(img, 900);
    src.gain = whiteGain(src);
    const { w, h, data } = src;
    const names = ['cyan', 'magenta', 'yellow', 'lime'];
    const cell = 3, gw = Math.ceil(w / cell), gh = Math.ceil(h / cell);
    const counts = names.map(() => new Uint16Array(gw * gh));
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      const hs = hsAt(src, i);
      if (hs.s < 0.28 || hs.v < 0.28) continue;
      let best = -1, bd = 32;
      for (let k = 0; k < 4; k++) { const d = hueDist(hs.h, HUES[names[k]]); if (d < bd) { bd = d; best = k; } }
      if (best >= 0) counts[best][((y / cell) | 0) * gw + ((x / cell) | 0)]++;
    }
    const minCell = Math.max(2, (cell * cell) >> 1);
    const cand = names.map((nm, k) => {
      const c = counts[k], seen = new Uint8Array(gw * gh), blobs = [], stack = [];
      for (let s0 = 0; s0 < c.length; s0++) {
        if (c[s0] < minCell || seen[s0]) continue;
        stack.length = 0; stack.push(s0); seen[s0] = 1;
        let n = 0, px = 0, sx = 0, sy = 0, x0 = 1e9, y0 = 1e9, x1 = -1, y1 = -1;
        while (stack.length) {
          const q = stack.pop(), qx = q % gw, qy = (q / gw) | 0, wt = c[q];
          n++; px += wt; sx += (qx + 0.5) * wt; sy += (qy + 0.5) * wt;
          if (qx < x0) x0 = qx; if (qx > x1) x1 = qx; if (qy < y0) y0 = qy; if (qy > y1) y1 = qy;
          for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
            const nx = qx + dx, ny = qy + dy;
            if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue;
            const r = ny * gw + nx;
            if (!seen[r] && c[r] >= minCell) { seen[r] = 1; stack.push(r); }
          }
        }
        const bw = x1 - x0 + 1, bh = y1 - y0 + 1;
        if (n < 3) continue;                                  // a speck
        if (n > gw * gh * 0.06) continue;                     // a wash of colour, not a target
        if (Math.max(bw, bh) > 4 * Math.min(bw, bh)) continue; // a stripe
        if (n < bw * bh * 0.3) continue;                      // a scatter, not a solid patch
        const b = { x: sx / px * cell, y: sy / px * cell, n, name: nm };
        b.ring = ringScore(src, b, Math.sqrt(n) * cell / 2);
        blobs.push(b);
      }
      blobs.sort((a, b) => b.n * (0.2 + b.ring) - a.n * (0.2 + a.ring));
      return blobs.slice(0, 6);
    });
    const missing = names.filter((nm, k) => !cand[k].length);
    if (missing.length) {
      const e = new Error('could not find the ' + missing.join(' and ') + ' corner' + (missing.length > 1 ? 's' : '') +
        ' — keep all four colour squares in the frame, and not too close');
      e.candidates = cand; e.scale = [src.scaleX, src.scaleY]; throw e;
    }
    const cross = (o, a, b) => (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);
    let best = null, bestScore = 0;
    for (const A of cand[0]) for (const B of cand[1]) for (const C of cand[2]) for (const D of cand[3]) {
      const q = [A, B, C, D];
      const z = [cross(A, B, C), cross(B, C, D), cross(C, D, A), cross(D, A, B)];
      if (!(z.every(v => v > 0) || z.every(v => v < 0))) continue;   // convex, in order round
      const area = Math.abs(z[0] + z[2]) / 2;
      // the targets are the same size: penalise a set whose blobs differ wildly
      const ns = q.map(b => b.n), ratio = Math.min(...ns) / Math.max(...ns);
      const ring = (A.ring + B.ring + C.ring + D.ring) / 4;
      const score = area * (0.3 + ratio) * (0.2 + ring);
      if (score > bestScore) { bestScore = score; best = q; }
    }
    if (!best || bestScore < w * h * 0.01) {
      const e = new Error('found the colours but not as four corners of the picture — step back so the whole projection is in the photo');
      e.candidates = cand; e.scale = [src.scaleX, src.scaleY]; throw e;
    }
    // the blob centres are good to a few pixels of the small copy; refine each on a bigger copy
    const big = canvasOf(img, 2400), k = big.w / w;
    big.gain = src.gain;
    return best.map(b => {
      const r = refine(big, b.x * k, b.y * k, Math.sqrt(b.n) * cell / 2 * k, HUES[b.name]);
      return { x: r.x * big.scaleX, y: r.y * big.scaleY, name: b.name };
    });
  }
  // Each target is a colour square inside a white ring inside a black pad. Score how much a blob looks like that:
  // bright, pale samples round it at ~1.4x its half-size, darker ones at ~2.1x.
  function ringScore(src, b, hs) {
    const { w, h, data } = src;
    const at = (x, y) => { x = Math.round(x); y = Math.round(y); if (x < 0 || y < 0 || x >= w || y >= h) return null; return hsAt(src, (y * w + x) * 4); };
    let good = 0, n = 0;
    for (let a = 0; a < 16; a++) {
      const ca = Math.cos(a * Math.PI / 8), sa = Math.sin(a * Math.PI / 8);
      const f = Math.max(Math.abs(ca), Math.abs(sa));           // square, not round
      const ring = at(b.x + ca / f * hs * 1.4, b.y + sa / f * hs * 1.4), pad = at(b.x + ca / f * hs * 2.1, b.y + sa / f * hs * 2.1);
      n++;
      if (ring && pad && ring.s < 0.4 && ring.v > 0.3 && ring.v > pad.v * 1.4) good++;
    }
    return good / n;
  }
  // Colour centroid of the square near (x, y) on the big copy.
  function refine(src, x, y, hs, hue) {
    const { w, h } = src, R = Math.ceil(hs * 1.25);
    const x0 = Math.max(0, Math.floor(x - R)), x1 = Math.min(w, Math.ceil(x + R)), y0 = Math.max(0, Math.floor(y - R)), y1 = Math.min(h, Math.ceil(y + R));
    let vmax = 0;
    for (let yy = y0; yy < y1; yy++) for (let xx = x0; xx < x1; xx++) {
      const q = hsAt(src, (yy * w + xx) * 4);
      if (q.s >= 0.28 && hueDist(q.h, hue) < 32 && q.v > vmax) vmax = q.v;
    }
    // a looser cut relative to the target's own brightness, so projector falloff doesn't eat one side of it
    let sx = 0, sy = 0, n = 0;
    for (let yy = y0; yy < y1; yy++) for (let xx = x0; xx < x1; xx++) {
      const q = hsAt(src, (yy * w + xx) * 4);
      if (q.s < 0.2 || q.v < vmax * 0.35 || hueDist(q.h, hue) >= 40) continue;
      sx += xx + 0.5; sy += yy + 0.5; n++;
    }
    return n > 8 ? { x: sx / n, y: sy / n } : { x, y };
  }

  /** A small copy of the photo with the corners it found (or the blobs it tried), for the mapping screen. */
  function drawFound(canvas, img, spec) {
    const g = canvas.getContext('2d');
    const s = Math.min(canvas.width / img.width, canvas.height / img.height);
    const dw = img.width * s, dh = img.height * s, ox = (canvas.width - dw) / 2, oy = (canvas.height - dh) / 2;
    g.fillStyle = '#000'; g.fillRect(0, 0, canvas.width, canvas.height);
    g.drawImage(img, ox, oy, dw, dh);
    const cols = { cyan: '#00ffff', magenta: '#ff00ff', yellow: '#ffff00', lime: '#00ff00' };
    try {
      const pts = findCorners(img, spec);
      g.strokeStyle = '#fff'; g.lineWidth = 2; g.beginPath();
      pts.forEach((p, i) => { const x = ox + p.x * s, y = oy + p.y * s; i ? g.lineTo(x, y) : g.moveTo(x, y); });
      g.closePath(); g.stroke();
      pts.forEach(p => { g.fillStyle = cols[p.name]; g.beginPath(); g.arc(ox + p.x * s, oy + p.y * s, 6, 0, 7); g.fill(); g.stroke(); });
      return { ok: true };
    } catch (e) {
      (e.candidates || []).forEach(list => list.forEach(b => {
        g.strokeStyle = cols[b.name]; g.lineWidth = 2; g.beginPath();
        g.arc(ox + b.x * e.scale[0] * s, oy + b.y * e.scale[1] * s, 7, 0, 7); g.stroke();
      }));
      return { ok: false, error: e.message };
    }
  }

  // 3x3 homography: dest = H * src (photo -> projector)
  function homography(src, dst) {
    // DLT, 8 unknowns
    const A = [];
    for (let i = 0; i < 4; i++) {
      const x = src[i].x, y = src[i].y, u = dst[i].x, v = dst[i].y;
      A.push([ x, y, 1, 0, 0, 0, -u*x, -u*y, -u ]);
      A.push([ 0, 0, 0, x, y, 1, -v*x, -v*y, -v ]);
    }
    // solve A h = 0 with h[8]=1 via last column
    const M = A.map(r => r.slice(0, 8).concat(-r[8]));
    const h = solve8(M);
    h.push(1);
    return h;
  }
  function solve8(M) { // 8x9 augmented, gaussian
    const n = 8;
    for (let i = 0; i < n; i++) {
      let p = i;
      for (let r = i + 1; r < n; r++) if (Math.abs(M[r][i]) > Math.abs(M[p][i])) p = r;
      const tmp = M[i]; M[i] = M[p]; M[p] = tmp;
      const piv = M[i][i];
      if (Math.abs(piv) < 1e-12) throw new Error('could not fit the four corners (they may be in a line)');
      for (let c = i; c <= n; c++) M[i][c] /= piv;
      for (let r = 0; r < n; r++) if (r !== i) {
        const f = M[r][i];
        for (let c = i; c <= n; c++) M[r][c] -= f * M[i][c];
      }
    }
    return M.map(r => r[8]);
  }
  function invH(H) {
    const a=H[0],b=H[1],c=H[2],d=H[3],e=H[4],f=H[5],g=H[6],h=H[7],i=H[8];
    const A = e*i-f*h, B = c*h-b*i, C = b*f-c*e;
    const D = f*g-d*i, E = a*i-c*g, F = c*d-a*f;
    const G = d*h-e*g, Hh= b*g-a*h, I = a*e-b*d;
    const det = a*A + b*D + c*G;
    if (Math.abs(det) < 1e-12) throw new Error('bad homography');
    return [A,B,C,D,E,F,G,Hh,I].map(v => v / det);
  }
  function applyH(H, x, y) {
    const w = H[6]*x + H[7]*y + H[8], u = (H[0]*x + H[1]*y + H[2]) / w, v = (H[3]*x + H[4]*y + H[5]) / w;
    return { x:u, y:v };
  }

  function warp(img, H, dw, dh) {
    const src = canvasOf(img, 2000);
    const inv = invH(H);
    const out = new Float32Array(dw * dh); // luma
    const rgba = new Uint8ClampedArray(dw * dh * 4);
    const { w, h, data } = src;
    for (let y = 0; y < dh; y++) for (let x = 0; x < dw; x++) {
      const p = applyH(inv, x + 0.5, y + 0.5);
      const sx = p.x, sy = p.y;
      let lum = 0, r=0, g=0, b=0, ok = 0;
      if (sx >= 1 && sy >= 1 && sx < w-1 && sy < h-1) {
        const x0 = Math.floor(sx), y0 = Math.floor(sy), tx = sx - x0, ty = sy - y0;
        const i00 = (y0*w+x0)*4, i10 = i00+4, i01 = ((y0+1)*w+x0)*4, i11 = i01+4;
        const w00=(1-tx)*(1-ty), w10=tx*(1-ty), w01=(1-tx)*ty, w11=tx*ty;
        r = data[i00]*w00 + data[i10]*w10 + data[i01]*w01 + data[i11]*w11;
        g = data[i00+1]*w00 + data[i10+1]*w10 + data[i01+1]*w01 + data[i11+1]*w11;
        b = data[i00+2]*w00 + data[i10+2]*w10 + data[i01+2]*w01 + data[i11+2]*w11;
        lum = 0.3*r + 0.59*g + 0.11*b; ok = 1;
      }
      const i = y*dw+x;
      out[i] = ok ? lum : -1;
      rgba[i*4] = r; rgba[i*4+1] = g; rgba[i*4+2] = b; rgba[i*4+3] = ok ? 255 : 0;
    }
    return { luma: out, rgba, w: dw, h: dh };
  }

  function Hfrom(img, spec) {
    const found = findCorners(img, spec);
    const src = found.map(p => ({ x: p.x, y: p.y }));
    const dst = spec.corners.map(c => ({ x: c.x * PW, y: c.y * PH }));
    return homography(src, dst);
  }

  function classify(imgs, spec) {
    // Score each photo: mean luma of the warped interior, and checker energy
    const scored = [];
    for (const img of imgs) {
      let H;
      try { H = Hfrom(img, spec); }
      catch (e) { e.message = 'photo ' + (imgs.indexOf(img) + 1) + ': ' + e.message; throw e; }
      const sx = 214 / PW, sy = 120 / PH;  // a small copy of projector space: scale H down to it
      const Hs = H.slice(); for (let k = 0; k < 3; k++) { Hs[k] *= sx; Hs[3 + k] *= sy; }
      const w = warp(img, Hs, 214, 120); // cheap
      let sum = 0, n = 0, tog = 0;
      const m = 0.18, x0 = (m*214)|0, x1 = ((1-m)*214)|0, y0=(m*120)|0, y1=((1-m)*120)|0;
      for (let y=y0;y<y1;y++) for (let x=x0;x<x1;x++) {
        const v = w.luma[y*214+x]; if (v < 0) continue;
        sum += v; n++;
        const cell = (((x-x0)/((x1-x0)/8))|0) + (((y-y0)/((y1-y0)/5))|0);
        tog += (cell & 1) ? v : -v;
      }
      scored.push({ img, mean: n?sum/n:0, grid: Math.abs(tog), H });
    }
    if (scored.length < 2) throw new Error('need at least two photos (black and white)');
    const byMean = scored.slice().sort((a,b) => a.mean - b.mean);
    const black = byMean[0];
    const rest = byMean.slice(1);
    rest.sort((a,b) => b.grid - a.grid);
    const grid = rest.length > 1 && rest[0].grid > rest[rest.length-1].grid * 1.2 ? rest[0] : null;
    const white = rest.filter(s => s !== grid).sort((a,b) => b.mean - a.mean)[0] || rest[0];
    const out = [ { frame:0, img: black.img }, { frame:1, img: white.img } ];
    if (grid) out[2] = { frame:2, img: grid.img };
    return out;
  }

  // The wall level (white minus black) changes a lot across a photo: projector falloff, camera vignetting, a lamp.
  // So judge each pixel against the wall near it: the 80th percentile of its block, smoothed over neighbours.
  function localRef(d) {
    const B = 32, bw = Math.ceil(PW / B), bh = Math.ceil(PH / B), lv = new Float32Array(bw * bh).fill(NaN);
    const buf = [];
    for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) {
      buf.length = 0;
      for (let y = by * B; y < Math.min(PH, by * B + B); y++) for (let x = bx * B; x < Math.min(PW, bx * B + B); x++) {
        const v = d[y * PW + x]; if (v >= 0) buf.push(v);
      }
      if (buf.length < B * B * 0.3) continue;
      buf.sort((p, q) => p - q);
      lv[by * bw + bx] = buf[Math.floor(buf.length * 0.8)];
    }
    // fill gaps, then take the max of the 5x5 neighbourhood median so a block filled by one big object still
    // sees the wall around it
    const all = Array.from(lv).filter(v => !isNaN(v)).sort((p, q) => p - q);
    const glob = all.length ? all[Math.floor(all.length * 0.8)] : 30;
    const sm = new Float32Array(bw * bh);
    for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) {
      buf.length = 0;
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) {
        const x = bx + dx, y = by + dy; if (x < 0 || y < 0 || x >= bw || y >= bh) continue;
        const v = lv[y * bw + x]; if (!isNaN(v)) buf.push(v);
      }
      buf.sort((p, q) => p - q);
      let v = buf.length ? buf[Math.floor(buf.length * 0.75)] : glob;
      v = Math.max(v, glob * 0.25);       // never trust a block far darker than the wall as a whole
      sm[by * bw + bx] = Math.max(4, v);
    }
    const ref = new Float32Array(PW * PH);
    for (let y = 0; y < PH; y++) for (let x = 0; x < PW; x++) {
      const fx = Math.min(bw - 1, Math.max(0, (x + 0.5) / B - 0.5)), fy = Math.min(bh - 1, Math.max(0, (y + 0.5) / B - 0.5));
      const x0 = Math.floor(fx), y0 = Math.floor(fy), x1 = Math.min(bw - 1, x0 + 1), y1 = Math.min(bh - 1, y0 + 1), tx = fx - x0, ty = fy - y0;
      ref[y * PW + x] = (sm[y0*bw+x0] * (1-tx) + sm[y0*bw+x1] * tx) * (1-ty) + (sm[y1*bw+x0] * (1-tx) + sm[y1*bw+x1] * tx) * ty;
    }
    return { ref, glob };
  }

  // The wall's own colour near each pixel (chromaticity of the white photo), so a green plant on a beige wall
  // stands out even when it is about as bright as the wall.
  function localChroma(rgba, d, ref) {
    const B = 32, bw = Math.ceil(PW / B), bh = Math.ceil(PH / B);
    const cr = new Float32Array(bw * bh).fill(NaN), cg = new Float32Array(bw * bh).fill(NaN);
    const ar = [], ag = [];
    const med = a => { a.sort((p, q) => p - q); return a[a.length >> 1]; };
    for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) {
      ar.length = 0; ag.length = 0;
      for (let y = by * B; y < Math.min(PH, by * B + B); y++) for (let x = bx * B; x < Math.min(PW, bx * B + B); x++) {
        const i = y * PW + x; if (d[i] < ref[i] * 0.6) continue;
        const r = rgba[i*4], g = rgba[i*4+1], b = rgba[i*4+2], sum = r + g + b + 1;
        ar.push(r / sum); ag.push(g / sum);
      }
      if (ar.length < B * B * 0.2) continue;
      cr[by * bw + bx] = med(ar); cg[by * bw + bx] = med(ag);
    }
    const out = { r: new Float32Array(bw * bh), g: new Float32Array(bw * bh), B, bw };
    for (const [src, dst] of [[cr, out.r], [cg, out.g]]) {
      const all = Array.from(src).filter(v => !isNaN(v)); const glob = all.length ? med(all) : 1 / 3;
      for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) {
        const a = [];
        for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) {
          const x = bx + dx, y = by + dy; if (x < 0 || y < 0 || x >= bw || y >= bh) continue;
          const v = src[y * bw + x]; if (!isNaN(v)) a.push(v);
        }
        dst[by * bw + bx] = a.length ? med(a) : glob;
      }
    }
    return out;
  }

  // Drop blobs smaller than minA and fill enclosed holes smaller than minHole.
  function despeck(m, minA, minHole) {
    const lab = new Int32Array(PW * PH), st = [];
    for (const want of [255, 0]) {
      lab.fill(0); let id = 0;
      for (let s0 = 0; s0 < m.length; s0++) {
        if (m[s0] !== want || lab[s0]) continue;
        id++; st.length = 0; st.push(s0); lab[s0] = id;
        const cells = []; let edge = false;
        while (st.length) {
          const q = st.pop(); cells.push(q);
          const x = q % PW, y = (q / PW) | 0;
          if (x === 0 || y === 0 || x === PW - 1 || y === PH - 1) edge = true;
          if (x > 0 && !lab[q-1] && m[q-1] === want) { lab[q-1] = id; st.push(q-1); }
          if (x < PW-1 && !lab[q+1] && m[q+1] === want) { lab[q+1] = id; st.push(q+1); }
          if (y > 0 && !lab[q-PW] && m[q-PW] === want) { lab[q-PW] = id; st.push(q-PW); }
          if (y < PH-1 && !lab[q+PW] && m[q+PW] === want) { lab[q+PW] = id; st.push(q+PW); }
        }
        if (cells.length < (want === 255 ? minA : minHole) && (want === 255 || !edge)) for (const q of cells) m[q] = 255 - want;
      }
    }
  }

  function build(photos, spec, thr) {
    const black = photos.find(p => p && p.frame === 0) || photos[0];
    const white = photos.find(p => p && p.frame === 1) || photos[1];
    const grid  = photos.find(p => p && p.frame === 2);
    if (!black || !white) throw new Error('need the black and white photos');
    const H = (img, nm) => { try { return Hfrom(img, spec); } catch (e) { e.message = 'the ' + nm + ' photo: ' + e.message; throw e; } };
    const Hb = H(black.img, 'black'), Hw = H(white.img, 'white');
    const Wb = warp(black.img, Hb, PW, PH), Ww = warp(white.img, Hw, PW, PH);
    let Wg = null;
    if (grid) { try { Wg = warp(grid.img, Hfrom(grid.img, spec), PW, PH); } catch (e) { Wg = null; } }

    const N = PW * PH, d = new Float32Array(N);
    for (let i = 0; i < N; i++) { const a = Ww.luma[i], b = Wb.luma[i]; d[i] = (a < 0 || b < 0) ? -1 : Math.max(0, a - b); }
    const { ref, glob } = localRef(d);
    const T = thr / 40;                  // 18 → under 45% of the wall near it
    const ch = localChroma(Ww.rgba, d, ref), CT = 0.07 * 18 / thr;

    // the checkerboard, as Patterns.drawGrid draws it
    const gs = spec.grid || { cols: 8, rows: 5 }, cols = gs.cols || 8, rows = gs.rows || 5;
    const t = spec.target || 0.075, mg = spec.margin || 0.10, gm = mg + t + 0.02;
    const gx0 = gm * PW, gy0 = gm * PH, gcw = (1 - 2 * gm) * PW / cols, gch = (1 - 2 * gm) * PH / rows;
    const tol = 4;                       // pixels either side of a cell edge we don't judge (registration slop)
    const cs = [[mg,mg],[1-mg,mg],[1-mg,1-mg],[mg,1-mg]];

    const mask = new Uint8Array(N);
    for (let y = 0; y < PH; y++) for (let x = 0; x < PW; x++) {
      const i = y * PW + x;
      if (d[i] < 0) continue;
      let near = false;
      for (const c of cs) if (Math.abs(x/PW - c[0]) < t * 1.08 && Math.abs(y/PH - c[1]) < t * 1.08 * (PW/PH)) near = true;
      if (near) continue;                // the colour targets themselves are not objects
      const lvl = ref[i], r = d[i] / lvl;
      let obj = r < T;
      if (!obj && r > 0.15) {
        const bi = Math.min(ch.bw - 1, (x / ch.B) | 0) + ((y / ch.B) | 0) * ch.bw;
        const R = Ww.rgba[i*4], G = Ww.rgba[i*4+1], Bl = Ww.rgba[i*4+2], sum = R + G + Bl + 1;
        if (Math.abs(R / sum - ch.r[bi]) + Math.abs(G / sum - ch.g[bi]) > CT) obj = true;   // a different colour from the wall
      }
      if (!obj && Wg && Wg.luma[i] >= 0) {
        const u = (x + 0.5 - gx0) / gcw, v = (y + 0.5 - gy0) / gch;
        if (u >= 0 && v >= 0 && u < cols && v < rows) {
          const fu = (u - Math.floor(u)) * gcw, fv = (v - Math.floor(v)) * gch;
          if (fu > tol && fu < gcw - tol && fv > tol && fv < gch - tol) {
            const expectWhite = ((Math.floor(u) + Math.floor(v)) & 1) === 1;
            const rg = (Wg.luma[i] - Wb.luma[i]) / Math.max(d[i], lvl * 0.25);
            if (expectWhite ? rg < 0.45 : rg > 0.55) obj = true;   // the pattern landed somewhere else: off the wall
          }
        }
      }
      if (obj) mask[i] = 255;
    }
    // clean: close small gaps, open away thin noise, then drop specks and fill pinholes
    morph(mask, PW, PH, 2, true); morph(mask, PW, PH, 2, false);
    morph(mask, PW, PH, 1, false); morph(mask, PW, PH, 1, true);
    despeck(mask, Math.round(N * 0.002), Math.round(N * 0.006));

    const prev = new Uint8ClampedArray(N * 4);
    let cover = 0;
    for (let i = 0; i < N; i++) {
      const pr = Ww.rgba[i*4], pg = Ww.rgba[i*4+1], pb = Ww.rgba[i*4+2];
      prev[i*4] = pr; prev[i*4+1] = pg; prev[i*4+2] = pb; prev[i*4+3] = 255;
      if (d[i] < 0) { prev[i*4] = 40; prev[i*4+1] = 0; prev[i*4+2] = 0; }   // not in the photo
      if (mask[i]) { cover++; prev[i*4] = Math.min(255, pr + 90); prev[i*4+1] = pg * 0.7; prev[i*4+2] = Math.min(255, pb + 50); }
    }
    window._prevImg = { rgba: prev, w: PW, h: PH };
    return { mask, preview: window._prevImg, med: glob, T, cover: cover / N };
  }

  function morph(m, w, h, r, dilate) {
    const out = new Uint8Array(m);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      let v = dilate ? 0 : 255;
      for (let dy=-r; dy<=r; dy++) for (let dx=-r; dx<=r; dx++) {
        const xx=x+dx, yy=y+dy; if (xx<0||yy<0||xx>=w||yy>=h) continue;
        const p = m[yy*w+xx];
        if (dilate) { if (p) v=255; } else { if (!p) v=0; }
      }
      out[y*w+x] = v;
    }
    m.set(out);
  }

  function drawPreview(canvas, r) {
    const g = canvas.getContext('2d');
    const img = r.preview || r;
    const im = g.createImageData(PW, PH);
    im.data.set(img.rgba);
    const tmp = document.createElement('canvas'); tmp.width=PW; tmp.height=PH;
    tmp.getContext('2d').putImageData(im,0,0);
    g.drawImage(tmp, 0, 0, canvas.width, canvas.height);
  }
  function maskPng(mask) {
    const c = document.createElement('canvas'); c.width=PW; c.height=PH;
    const g = c.getContext('2d');
    const im = g.createImageData(PW, PH);
    for (let i=0;i<PW*PH;i++) {
      const v = mask[i] ? 255 : 0;
      im.data[i*4]=v; im.data[i*4+1]=v; im.data[i*4+2]=v; im.data[i*4+3]=255;
    }
    g.putImageData(im,0,0);
    const data = c.toDataURL('image/png');
    return data.split(',')[1];
  }

  return { loadImage, findCorners, drawFound, classify, build, drawPreview, maskPng, Hfrom, homography, invH, applyH };
})();
