
/* Astro Lava control panel: effect picks, sliders, webcam/phone mapping, optional Pi/USB import. */
const $ = (s, r=document) => r.querySelector(s);
let S = null;

async function api(path, body, method) {
  const opt = { method: method || (body === undefined ? 'GET' : 'POST'), headers: {} };
  if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
  const r = await fetch(path, opt);
  const t = await r.text();
  if (!r.ok) throw new Error(t || r.status);
  try { return JSON.parse(t); } catch (e) { return t; }
}

/* the status line on Play (kept up to date by refresh) */
function setLine(msg, ok) {
  const el = $('#status'); el.textContent = msg; el.className = 'status' + (ok === false ? ' bad' : '');
}
/* what a button just did: the status line, and a toast at the bottom center that goes away by itself */
let toastT = 0;
function setStatus(msg, ok) {
  setLine(msg, ok);
  const t = $('#toast'); if (!t) return;
  t.textContent = msg; t.classList.add('on');
  clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('on'), ok === false ? 9000 : Math.min(7000, 2500 + msg.length * 40));
}

/* pages: #/play, #/map, #/widgets, #/settings (the tab bar on phones, a side rail on wide screens) */
(() => {
  const pages = [...document.querySelectorAll('.page')], name = $('#pagename');
  let cur = null;
  const go = id => {
    const pg = $('#p-' + id) || $('#p-play'); id = pg.id.slice(2);
    pages.forEach(x => { x.hidden = x !== pg; });
    document.querySelectorAll('.tabs a').forEach(a => {
      if (a.dataset.tab === id) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
    if (name) name.textContent = id === 'play' ? '' : pg.dataset.title;
    document.title = 'Astro Lava' + (id === 'play' ? '' : ' · ' + pg.dataset.title);
    try { localStorage.setItem('astro.page', id); } catch (e) {}
    cur = id;
  };
  const fromHash = () => {
    const h = (location.hash || '').replace(/^#\/?/, '');
    if (h && !$('#p-' + h)) return false;          // the skip link's #main: not a page
    let saved = null; try { saved = localStorage.getItem('astro.page'); } catch (e) {}
    go(h || cur || saved || 'play');
    return true;
  };
  addEventListener('hashchange', () => { if (fromHash()) scrollTo(0, 0); });
  fromHash();
})();

async function refresh() {
  S = await api('/api/state');
  $('#ver').textContent = 'v' + (S.version || '0.2.2');
  const fx = $('#fx'); fx.innerHTML = '';
  (S.effects || []).forEach(e => {
    const b = document.createElement('button');
    b.textContent = e.label; if (e.id === S.effect) b.className = 'on';
    b.onclick = () => save({ effect: e.id });
    fx.appendChild(b);
  });
  renderSliders();
  renderWidgets();
  const sc = S.scan || {};
  $('#scanInfo').textContent = S.hasScan
    ? ('Map from ' + (sc.source || '?') + (sc.created ? ' · ' + String(sc.created).replace('T', ' ').slice(0, 16) : ''))
    : 'No map yet. Effects fill the whole wall.';
  $('#piUrl').value = S.piUrl || '';
  const places = S.places || [], psel = $('#place');
  $('#placeRow').hidden = $('#placeInfo').hidden = !places.length;
  if (document.activeElement !== psel) {
    psel.innerHTML = '';
    if (!S.place) psel.appendChild(new Option("This Astro's own map", ''));
    places.forEach(p => psel.appendChild(new Option(p.name + (p.piCurrent ? ' (on the Pi now)' : ''), p.id)));
    psel.value = S.place || '';
  }
  const cam = $('#camInfo');
  if (cam) {
    if (S.usbCameras > 0) cam.textContent = 'Webcam ready' + (S.usbCamName ? ': ' + S.usbCamName : '') + '. Map with webcam projects black, white, then the checkerboard, and saves the map. The camera is released afterwards. Phone photos remain a fallback.';
    else if (S.usbHost) cam.textContent = 'No USB camera found. Plug the C615 into the Astro\'s USB (or a hub), or map with phone photos instead.';
    else cam.textContent = "This Astro doesn't expose USB host, so the webcam can't be used. Map with your phone instead.";
  }
  const camBtn = $('#mapCam');
  if (camBtn) camBtn.disabled = !!S.mapBusy;
  const fps = S.fps ? Math.round(S.fps) + ' fps' : '';
  const upd = $('#updateInfo');
  if (upd) {
    const bits = [];
    bits.push('App v' + (S.version || '') + ' · content ' + (S.contentVersion || '?') + (S.contentSource && S.contentSource !== 'current' ? ' (' + S.contentSource + ')' : ''));
    if (S.updateStatus) bits.push(S.updateStatus);
    upd.textContent = bits.join(' — ');
  }
  const chk = $('#checkUpdate');
  // a downloaded app update can always be installed again (the installer may have been dismissed)
  if (chk) { chk.disabled = !!S.updateBusy && !S.updateReady; chk.textContent = S.updateReady ? 'Install update' : 'Check for update'; }
  if (S.updateStatus) setLine(S.updateStatus, S.updateError ? false : true);
  else if (S.mapStatus) setLine(S.mapStatus, S.mapError ? false : true);
  else setLine((S.banner ? S.banner + '  ·  ' : '') + (S.effect || '') + (fps ? '  ·  ' + fps : ''), true);
  const pl = $('#piLink');
  if (pl) pl.innerHTML = /^https?:\/\//.test(S.piUrl || '') ? 'Pi control panel: <a href="' + encodeURI(S.piUrl) + '">' + S.piUrl.replace(/[<>&"]/g, '') + '</a>' : '';
}

function slider(id, label, min, max, step, val, key) {
  const wrap = document.createElement('label');
  wrap.innerHTML = label + ' <span class=row><input type=range min='+min+' max='+max+' step='+step+' value="'+val+'"> <output>'+val+'</output></span>';
  const inp = wrap.querySelector('input'), out = wrap.querySelector('output');
  inp.oninput = () => { out.textContent = inp.value; };
  inp.onchange = () => { const o = {}; o[key] = +inp.value; save(o); };
  return wrap;
}
function toggle(label, key, val) {
  const wrap = document.createElement('label');
  wrap.innerHTML = '<span class=row>'+label+' <input type=checkbox '+(val?'checked':'')+'></span>';
  wrap.querySelector('input').onchange = ev => { const o = {}; o[key] = ev.target.checked; save(o); };
  return wrap;
}
function select(label, key, val, opts) {
  const wrap = document.createElement('label');
  wrap.appendChild(document.createTextNode(label + ' '));
  const s = document.createElement('select');
  opts.forEach(([v,l]) => { const o = document.createElement('option'); o.value=v; o.textContent=l; if (v===val) o.selected=true; s.appendChild(o); });
  s.onchange = () => { const o = {}; o[key] = s.value; save(o); };
  wrap.appendChild(s); return wrap;
}

function fieldValue(key, fallback) {
  if (S[key] !== undefined && S[key] !== null) return S[key];
  return fallback;
}
function renderFromSchema(box, sliders) {
  sliders.forEach(s => {
    const key = s.key;
    if (!key) return;
    const typ = s.type || (s.options ? 'select' : (typeof s.default === 'boolean' ? 'toggle' : 'slider'));
    if (typ === 'toggle') box.appendChild(toggle(s.label || key, key, !!fieldValue(key, s.default)));
    else if (typ === 'select') box.appendChild(select(s.label || key, key, fieldValue(key, s.default), s.options || []));
    else box.appendChild(slider(key, s.label || key, s.min, s.max, s.step || 0.05, fieldValue(key, s.default), key));
  });
}
function renderSliders() {
  const box = $('#sliders'); box.innerHTML = '<h2>Tuning</h2>';
  const e = S.effect;
  const def = (S.effects || []).find(x => x.id === e);
  if (def && def.sliders && def.sliders.length) {
    renderFromSchema(box, def.sliders);
    return;
  }
  box.appendChild(slider('int', 'Intensity', 0.2, 2, 0.05, S.intensity, 'intensity'));
  box.appendChild(slider('spd', 'Speed', 0.2, 3, 0.05, S.fxSpeed, 'fxSpeed'));
  if (e === 'wax' || e === 'clock') {
    box.appendChild(slider('heat', 'Heat', 0.3, 3, 0.05, S.heat, 'heat'));
    box.appendChild(slider('size', 'Blob size', 0.5, 2, 0.05, S.size, 'size'));
    box.appendChild(slider('blobs', 'Blobs', 2, 16, 1, S.blobs, 'blobs'));
    box.appendChild(slider('pal', 'Palette', 0, 19, 1, S.palette, 'palette'));
    if (e === 'clock') box.appendChild(select('Timezone', 'tz', S.tz, [
      ['America/Los_Angeles','Pacific'], ['America/Denver','Mountain'], ['America/Chicago','Central'],
      ['America/New_York','Eastern'], ['UTC','UTC']
    ]));
  }
  if (e === 'lava') {
  }
  if (e === 'rain') {
    box.appendChild(select('Weather', 'weather', S.weather, [['auto','Auto (take turns)'],['rain','Rain'],['snow','Snow']]));
  }
  if (e === 'ivy') {
    box.appendChild(toggle('Moving sun', 'sunOn', S.sunOn));
    box.appendChild(slider('ss', 'Sun speed', 0.2, 3, 0.05, S.sunSpeed, 'sunSpeed'));
  }
  if (e === 'sweep') {
    box.appendChild(select('Direction', 'sweepMode', S.sweepMode, [['auto','Auto (changes every 45 s)'],['top','From the top'],['sunrise','Sunrise to sunset'],['orbit','Orbit'],['spotlight','Swinging spotlight']]));
  }
  box.appendChild(slider('hue', 'Hue shift', -180, 180, 5, S.hue || 0, 'hue'));
  box.appendChild(slider('sat', 'Saturation', 0, 2, 0.05, S.sat == null ? 1 : S.sat, 'sat'));
  box.appendChild(toggle('Show mask (debug)', 'debugMask', S.debugMask));
}

/* ---- widgets (same settings as the Pi's Widgets card) ---- */
const WIDGETS = [['clock','🕰️ Lava clock'],['weather','⛅ Weather'],['outdoor','🌡️ Outdoor temperature'],
  ['indoor','🏠 Indoor temperature (Nest, via the Pi)'],['car','🔋 Tesla charge'],['door','🔔 Doorbell (Nest, via the Pi)']];
const wOpen = {};
function wSave(o) { return save({ widgets: o }); }
function wRow(label, inner) { const l = document.createElement('label'); l.textContent = label + ' '; l.appendChild(inner); return l; }
function wRange(key, label, min, max, step, val) {
  const wrap = document.createElement('label');
  wrap.innerHTML = label + ' <span class=row><input type=range min='+min+' max='+max+' step='+step+' value="'+val+'"> <output>'+val+'</output></span>';
  const inp = wrap.querySelector('input'), out = wrap.querySelector('output');
  inp.oninput = () => { out.textContent = inp.value; };
  inp.onchange = () => { const o = {}; o[key] = +inp.value; wSave(o); };
  return wrap;
}
function wSelect(key, label, val, opts, top) {
  const s = document.createElement('select');
  opts.forEach(([v,l]) => { const o = document.createElement('option'); o.value=v; o.textContent=l; if (String(v)===String(val)) o.selected=true; s.appendChild(o); });
  s.onchange = () => { const o = {}; o[key] = /^\d+$/.test(s.value) ? +s.value : s.value; top ? save(o) : wSave(o); };
  return wRow(label, s);
}
function wCheck(key, label, val) {
  const l = document.createElement('label');
  l.innerHTML = '<span class=row>' + label + ' <input type=checkbox ' + (val ? 'checked' : '') + '></span>';
  l.querySelector('input').onchange = ev => { const o = {}; o[key] = ev.target.checked; wSave(o); };
  return l;
}
function wColorIn(key, label, val) {
  const i = document.createElement('input'); i.type = 'color'; i.value = val || '#ffffff';
  i.onchange = () => { const o = {}; o[key] = i.value; wSave(o); };
  return wRow(label, i);
}
function renderWidgets() {
  const W = S.widgets || {}, H = S.home || {}, E = H.errors || {};
  const box = $('#wList'); box.innerHTML = '';
  WIDGETS.forEach(([k, label]) => {
    const d = document.createElement('details'); d.open = !!wOpen[k];
    d.ontoggle = () => { wOpen[k] = d.open; };
    const sum = document.createElement('summary');
    const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = !!W[k];
    cb.onclick = ev => ev.stopPropagation();
    cb.onchange = () => { const o = {}; o[k] = cb.checked; wSave(o); };
    sum.appendChild(cb); sum.appendChild(document.createTextNode(' ' + label));
    d.appendChild(sum);
    d.appendChild(wSelect(k + '_spot', 'Spot', W[k + '_spot'] || 1, [[1,'1 (biggest)'],[2,'2'],[3,'3'],[4,'4'],[5,'5']]));
    d.appendChild(wRange(k + '_size', 'Size', 0.3, 1.5, 0.05, W[k + '_size'] || 1));
    d.appendChild(wRange(k + '_rot', 'Rotate', -180, 180, 5, W[k + '_rot'] || 0));
    if (k === 'clock') {
      d.appendChild(wSelect('clock_face', 'Face', W.clock_face || 'analog', [['analog','Wax hands'],['orbit','Orbit'],['neon','Neon tube'],['digital','Digital'],['segments','Digital (segments)']]));
      d.appendChild(wSelect('clock_ink', 'Colour', W.clock_ink || 'lava', [['lava','The lava palette'],['colour','My colour']]));
      if (W.clock_ink === 'colour' || W.clock_ink === 'color') {
        d.appendChild(wColorIn('clock_color', 'Clock colour', W.clock_color || '#ff8030'));
        d.appendChild(wColorIn('clock_color2', 'Seconds / date colour', W.clock_color2 || '#ffc090'));
      }
      d.appendChild(wRange('clock_back', 'Dark backing', 0, 1, 0.05, W.clock_back == null ? 0.8 : W.clock_back));
      d.appendChild(wCheck('h24', '24-hour', W.h24));
      d.appendChild(wCheck('date', 'Date (digital faces)', W.date !== false));
      d.appendChild(wSelect('tz', 'Time zone', S.tz, [['America/Los_Angeles','Pacific'],['America/Denver','Mountain'],['America/Chicago','Central'],['America/New_York','Eastern'],['UTC','UTC']], true));
    }
    if (k === 'door') {
      d.appendChild(wRange('door_s', 'Show for (seconds)', 10, 300, 5, W.door_s || 45));
      d.appendChild(wCheck('door_flash', 'Flash when it rings', W.door_flash !== false));
      const b = document.createElement('button'); b.type = 'button'; b.textContent = 'Test ring';
      b.onclick = () => save({ testRing: true }); d.appendChild(b);
    }
    box.appendChild(d);
  });
  $('#wFont').value = W.font || 'bubble';
  $('#wColor').value = W.color || '#ffffff';
  if (document.activeElement !== $('#wZip')) $('#wZip').value = W.zip || '';
  const wx = H.weather;
  $('#wZipInfo').textContent = E.weather ? E.weather : (W.place ? W.place + (wx ? ': ' + Math.round(wx.f) + '°F' : '') : 'Open-Meteo, no account needed.');
  $('#wCarInfo').textContent = E.car ? E.car : (S.tessieSet ? 'Token saved on the Astro.' + (H.car ? ' ' + H.car.name + ': ' + H.car.level + '%' : '') : "Leave empty to use the Pi's Tessie instead.");
  $('#wPiInfo').textContent = E.pi ? E.pi : (H.indoor != null ? 'From the Pi: inside ' + Math.round(H.indoor) + '°F' : '');
}
$('#wFont').onchange = () => wSave({ font: $('#wFont').value });
$('#wColor').onchange = () => wSave({ color: $('#wColor').value });
$('#wSpots').onclick = () => save({ findSpots: true });
$('#wZipSave').onclick = () => wSave({ zip: $('#wZip').value.trim() });
$('#wTessieSave').onclick = () => { save({ tessieToken: $('#wTessie').value.trim() }); $('#wTessie').value = ''; };

async function save(partial) {
  try { S = await api('/api/state', partial); await refresh(); }
  catch (e) { setStatus(String(e.message || e), false); }
}

$('#piImport').onclick = async () => {
  try {
    setStatus('Importing from the Pi…');
    await api('/api/import/pi', { url: $('#piUrl').value || S.piUrl });
    await refresh(); setStatus((S.places || []).length ? 'Imported ' + S.places.length + ' maps from the Pi' : 'Imported the Pi map', true);
  } catch (e) { setStatus('Pi import: ' + (e.message || e), false); }
};
$('#place').onchange = async () => {
  const id = $('#place').value; if (!id) return;
  try { S = await api('/api/place', { id }); await refresh(); setStatus('Using ' + $('#place').selectedOptions[0].text, true); }
  catch (e) { setStatus('Map: ' + (e.message || e), false); }
};
$('#usbImport').onclick = async () => {
  try { await api('/api/import/usb', {}); await refresh(); setStatus('Imported from USB', true); }
  catch (e) { setStatus('USB: ' + (e.message || e), false); }
};
$('#scanClear').onclick = async () => {
  if (!confirm('Clear the map? Effects will fill the whole wall.')) return;
  try { await api('/api/scan/clear', {}); await refresh(); } catch (e) { setStatus(String(e.message||e), false); }
};

/* ---- mapping UI ---- */
const MapUI = {
  photos: [], // {frame, img, file}
  mask: null,
};
const MAP_NAMES = ['black', 'white', 'checker'];
// A thumbnail per photo with the corners the mapper found, so a bad shot shows straight away.
async function mapThumbs() {
  const box = $('#mapThumbs'); box.textContent = '';
  const spec = await api('/api/map/spec');
  let allOk = true;
  Mapper.alignSet(MapUI.photos.map(p => p && p.img));
  for (const p of MapUI.photos) {
    if (!p) continue;
    const fig = document.createElement('figure');
    const c = document.createElement('canvas'); c.width = 240; c.height = 135;
    const r = Mapper.drawFound(c, p.img, spec);
    const cap = document.createElement('figcaption');
    cap.textContent = MAP_NAMES[p.frame] + (r.ok ? ' ✓' : ' ✗ ' + r.error);
    if (!r.ok) { fig.className = 'bad'; allOk = false; }
    fig.append(c, cap); box.append(fig);
  }
  $('#mapDl').hidden = !MapUI.photos.some(p => p && p.file);
  return allOk;
}
async function mapDownload() {
  const files = MapUI.photos.filter(p => p && p.file).map(p => {
    const ext = (p.file.name.match(/\.\w+$/) || ['.jpg'])[0];
    return new File([p.file], 'lava-map-' + MAP_NAMES[p.frame] + ext, { type: p.file.type || 'image/jpeg' });
  });
  if (!files.length) return;
  try {
    if (navigator.canShare && navigator.canShare({ files })) { await navigator.share({ files, title: 'Lava mapping photos' }); return; }
  } catch (e) { if (e.name === 'AbortError') return; }
  for (const f of files) {
    const a = document.createElement('a'); a.href = URL.createObjectURL(f); a.download = f.name;
    document.body.append(a); a.click(); a.remove();
    await new Promise(r => setTimeout(r, 400));
  }
}
$('#mapDl').onclick = () => mapDownload();
$('#olCard').addEventListener('toggle', () => { if ($('#olCard').open) Outline.open(); });
$('#mapCam').onclick = () => mapWebcam();
$('#mapStart').onclick = () => mapBegin(false);

async function mapWebcam() {
  try {
    setStatus('Starting webcam mapping…');
    await api('/api/map/webcam', {});
    for (let i = 0; i < 90; i++) {
      await new Promise(r => setTimeout(r, 700));
      await refresh();
      if (!S.mapBusy) {
        setStatus(S.mapStatus || (S.mapError ? 'Webcam mapping failed.' : 'Webcam map saved.'), S.mapError ? false : true);
        return;
      }
    }
    setStatus(S.mapStatus || 'Still mapping… refresh the page if this stalls.', false);
  } catch (e) {
    setStatus('Webcam: ' + (e.message || e), false);
  }
}

$('#mapBatch').onclick = () => $('#batch').click();
$('#mapShot').onclick = () => $('#shot').click();
$('#mapSkip').onclick = () => mapAdvance();
$('#mapCancel').onclick = () => mapEnd(true);
$('#mapSave').onclick = () => mapSave();
$('#shot').onchange = ev => { if (ev.target.files[0]) mapGotFile(ev.target.files[0], S && S.mapPattern >= 0 ? S.mapPattern : MapUI.photos.length); ev.target.value = ''; };
$('#batch').onchange = ev => { mapBatch(ev.target.files); ev.target.value = ''; };
$('#thr').oninput = () => { $('#thrV').textContent = $('#thr').value; if (MapUI.photos.length) mapPreview(); };
$('#mapBright').onchange = () => { if (MapUI.photos.length) mapPreview(true); };

async function mapBegin() {
  $('#mapUi').hidden = false;
  MapUI.photos = []; MapUI.mask = null; MapUI.objects = null; MapUI.gemFor = null; $('#mapGem').hidden = true; $('#mapBright').checked = true; $('#mapThumbs').textContent = ''; $('#mapDl').hidden = true;
  await api('/api/map', { action: 'start', frame: 0 });
  mapPrompt(0);
}
function mapPrompt(i) {
  const names = ['black (room + corners)', 'white (lit wall + corners)', 'checkerboard + corners'];
  $('#mapStep').textContent = 'Pattern ' + (i+1) + ' of 3: ' + names[i] + '. Fill the frame with the projection, keep the four colour corners visible, then take the photo.';
  $('#mapSave').hidden = true;
  $('#mapShot').disabled = false;
}
async function mapGotFile(file, frame) {
  const img = await Mapper.loadImage(file);
  MapUI.photos[frame] = { frame, img, file };
  const ok = await mapThumbs();
  if (!ok) {
    setStatus('Photo ' + (frame+1) + ': could not find the four colour corners. Take it again (or Skip).', false);
    return;                                    // stay on this pattern for a retake
  }
  setStatus('Got photo ' + (frame+1) + '/3', true);
  if (frame < 2) {
    await api('/api/map', { action: 'frame', frame: frame + 1 });
    mapPrompt(frame + 1);
  } else {
    await api('/api/map', { action: 'stop' });
    await mapPreview();
  }
}
async function mapAdvance() {
  const i = MapUI.photos.filter(Boolean).length;
  if (i < 3) { await api('/api/map', { action: 'frame', frame: i }); mapPrompt(i); }
  else await mapPreview();
}
async function mapBatch(files) {
  $('#mapUi').hidden = false;
  setStatus('Reading ' + files.length + ' photos…');
  const imgs = [], byImg = new Map();
  for (const f of files) { const im = await Mapper.loadImage(f); imgs.push(im); byImg.set(im, f); }
  // classify by brightness / grid after finding corners
  const spec = await api('/api/map/spec');
  try {
    MapUI.photos = Mapper.classify(imgs, spec).map(p => Object.assign(p, { file: byImg.get(p.img) }));
  } catch (e) {
    MapUI.photos = imgs.slice(0, 3).map((img, i) => ({ frame: i, img, file: byImg.get(img) }));
    await mapThumbs();
    setStatus('Mapping: ' + e.message, false); return;
  }
  await mapThumbs();
  await api('/api/map', { action: 'stop' });
  await mapPreview();
}
// Objects come from Gemini (through the Pi, with its key): it outlines real things like a frame, a triangle or bars
// that brightness alone misses on a dark wall. Brightness only fills in, and can be switched off.
async function mapGemini() {
  if (!MapUI.photo || MapUI.gemFor === MapUI.photo) return;
  MapUI.gemFor = MapUI.photo; MapUI.objects = null;
  const note = $('#mapGem'); note.hidden = false; note.textContent = 'Asking Gemini (through the Pi) to outline the objects…';
  try {
    const sg = await api('/api/gemini', { photo: MapUI.photo });
    if (sg.error) { note.textContent = 'Gemini: ' + sg.error + ' Using brightness only.'; return; }
    const objs = (sg.props || []).map((p, i) => Outline.fromProp(p, i)).filter(Boolean);
    if (!objs.length) { note.textContent = 'Gemini found nothing to outline. Using brightness only.'; return; }
    MapUI.objects = objs;
    note.textContent = 'Gemini outlined: ' + objs.map(o => o.label).join(', ') + '.';
    $('#mapBright').checked = false;
    await mapPreview(true);
  } catch (e) { note.textContent = 'Gemini: ' + (e.message || e) + '. Using brightness only.'; }
}
function polyMask(objs) {
  const c = document.createElement('canvas'); c.width = 854; c.height = 480;
  const g = c.getContext('2d'); g.fillStyle = '#fff';
  objs.forEach(o => { g.beginPath(); o.pts.forEach((p, k) => k ? g.lineTo(p[0] * 854, p[1] * 480) : g.moveTo(p[0] * 854, p[1] * 480)); g.closePath(); g.fill(); });
  const d = g.getImageData(0, 0, 854, 480).data, m = new Uint8Array(854 * 480);
  for (let i = 0; i < m.length; i++) m[i] = d[i * 4] > 127 ? 255 : 0;
  return m;
}
async function mapPreview(noGemini) {
  const spec = await api('/api/map/spec');
  const have = MapUI.photos.filter(Boolean);
  if (have.length < 2) { setStatus('Need at least the black and white photos', false); return; }
  try {
    const r = await Mapper.build(have, spec, +$('#thr').value);
    try { MapUI.photo = Mapper.photoJpeg(r.white); } catch (e) { MapUI.photo = null; }
    const bright = $('#mapBright').checked || !MapUI.objects;
    const mask = bright ? r.mask : new Uint8Array(r.mask.length);
    if (MapUI.objects) { const gm = polyMask(MapUI.objects); for (let i = 0; i < mask.length; i++) if (gm[i]) mask[i] = 255; }
    MapUI.mask = mask;
    // the preview: the white photo, objects tinted, Gemini's outlines drawn on top
    const pv = r.preview.rgba, wr = r.white.rgba;
    for (let i = 0; i < mask.length; i++) {
      const R = wr[i*4], G = wr[i*4+1], B = wr[i*4+2];
      pv[i*4] = mask[i] ? Math.min(255, R + 90) : R; pv[i*4+1] = mask[i] ? G * 0.7 : G; pv[i*4+2] = mask[i] ? Math.min(255, B + 50) : B;
    }
    Mapper.drawPreview($('#mapPrev'), r);
    if (MapUI.objects) {
      const g = $('#mapPrev').getContext('2d'), k = $('#mapPrev').width / 854;
      g.strokeStyle = '#7fdcff'; g.lineWidth = 3; g.font = 'bold 22px system-ui'; g.fillStyle = '#7fdcff';
      MapUI.objects.forEach(o => { g.beginPath(); o.pts.forEach((p, j) => j ? g.lineTo(p[0] * 854 * k, p[1] * 480 * k) : g.moveTo(p[0] * 854 * k, p[1] * 480 * k)); g.closePath(); g.stroke();
        g.fillText(o.label, o.pts[0][0] * 854 * k + 4, o.pts[0][1] * 480 * k - 6); });
    }
    $('#mapSave').hidden = false;
    let cover = 0; for (let i = 0; i < mask.length; i++) if (mask[i]) cover++;
    cover /= mask.length;
    if (cover > 0.6) setStatus('Most of the wall came out as objects. Turn off brightness, lower the threshold, or retake the photos.', false);
    else setStatus('Preview ready: objects are tinted pink. Save, then fine-tune in Outlines.', true);
    if (!noGemini) mapGemini();
  } catch (e) { setStatus('Mapping: ' + e.message, false); }
}
async function mapSave() {
  if (!MapUI.mask) { setStatus('Nothing to save yet', false); return; }
  const png = Mapper.maskPng(MapUI.mask);
  const r4 = v => Math.round(v * 10000) / 10000;
  const objects = (MapUI.objects || []).map(o => ({ label: o.label, shape: 'poly', points: o.pts.map(p => p.map(r4)) }));
  await api('/api/scan', {
    source: 'phone', mask_png: png, photo: MapUI.photo || undefined, objects: objects.length ? objects : undefined
  });
  window._mapPhoto = MapUI.photo;
  await api('/api/map', { action: 'stop' });
  setStatus('Map saved on the Astro', true);
  await refresh();
}
async function mapEnd(cancel) {
  await api('/api/map', { action: 'stop' });
  $('#mapUi').hidden = true;
  MapUI.photos = [];
  if (cancel) setStatus('Mapping cancelled');
}

refresh().catch(e => setStatus('Cannot reach the Astro: ' + e.message, false));
setInterval(() => { if (S) api('/api/state').then(s => { S.fps = s.fps; }).catch(() => {}); }, 4000);

$('#checkUpdate').onclick = async () => {
  try {
    const r = await api('/api/update/check', {});
    setStatus(r.ready ? 'Opening the installer on the projector: highlight Install and press OK on the remote.' : 'Checking for updates…', true);
    setTimeout(() => refresh().catch(() => {}), 3000);
  } catch (e) { setStatus('Update: ' + (e.message || e), false); }
};
$('#showQr').onclick = async () => {
  try { await api('/api/qr', {}); setStatus('QR codes are on the Astro for 20 seconds', true); }
  catch (e) { setStatus('Show QR: ' + (e.message || e), false); }
};
