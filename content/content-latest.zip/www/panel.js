
/* Astro Lava control panel: effect picks, sliders, webcam/phone mapping, optional Pi/USB import. */
const $ = (s, r=document) => r.querySelector(s);
let S = null;

async function api(path, body, method) {
  const opt = { method: method || (body === undefined ? 'GET' : 'POST'), headers: {} };
  if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
  const r = await fetch(path, opt);
  const t = await r.text();
  if (!r.ok) throw new Error(t || r.status);
  try { return JSON.parse(t); } catch (e) { return t; }
}

/* the status line on Play (kept up to date by refresh) */
function setLine(msg, ok) {
  const el = $('#status'); el.textContent = msg; el.className = 'status' + (ok === false ? ' bad' : '');
}
/* what a button just did: the status line, and a toast at the bottom center that goes away by itself */
let toastT = 0;
function setStatus(msg, ok) {
  setLine(msg, ok);
  const t = $('#toast'); if (!t) return;
  t.textContent = msg; t.classList.add('on');
  clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('on'), ok === false ? 9000 : Math.min(7000, 2500 + msg.length * 40));
}

/* pages: #/play, #/map, #/widgets, #/settings (the tab bar on phones, a side rail on wide screens) */
(() => {
  const pages = [...document.querySelectorAll('.page')], name = $('#pagename');
  let cur = null;
  const go = id => {
    const pg = $('#p-' + id) || $('#p-play'); id = pg.id.slice(2);
    pages.forEach(x => { x.hidden = x !== pg; });
    document.querySelectorAll('.tabs a').forEach(a => {
      if (a.dataset.tab === id) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
    if (name) name.textContent = id === 'play' ? '' : pg.dataset.title;
    document.title = 'Astro Lava' + (id === 'play' ? '' : ' · ' + pg.dataset.title);
    try { localStorage.setItem('astro.page', id); } catch (e) {}
    cur = id;
  };
  const fromHash = () => {
    const h = (location.hash || '').replace(/^#\/?/, '');
    if (h && !$('#p-' + h)) return false;          // the skip link's #main: not a page
    let saved = null; try { saved = localStorage.getItem('astro.page'); } catch (e) {}
    go(h || cur || saved || 'play');
    return true;
  };
  addEventListener('hashchange', () => { if (fromHash()) scrollTo(0, 0); });
  fromHash();
})();

async function refresh() {
  S = await api('/api/state');
  $('#ver').textContent = 'v' + (S.version || '0.2.2');
  const fx = $('#fx'); fx.innerHTML = '';
  (S.effects || []).forEach(e => {
    const b = document.createElement('button');
    b.textContent = e.label; if (e.id === S.effect) b.className = 'on';
    b.onclick = () => save({ effect: e.id });
    fx.appendChild(b);
  });
  renderSliders();
  renderWidgets();
  const sc = S.scan || {};
  const maps = S.maps || [], places = S.places || [], psel = $('#place');
  const curMap = maps.find(m => m.active), curPlace = places.find(p => p.id === S.place);
  const curName = curMap ? curMap.name : curPlace ? curPlace.name : sc.name;
  $('#scanInfo').textContent = S.hasScan
    ? (curName ? 'Using "' + curName + '"' : 'Using an unnamed map') + (sc.created ? ' · made ' + String(sc.created).replace('T', ' ').slice(0, 16) : '')
    : 'No map yet. Effects fill the whole wall. Tap Make a new map.';
  $('#piUrl').value = S.piUrl || '';
  $('#placeRow').hidden = !(maps.length + places.length);
  $('#placeInfo').hidden = !places.length;
  if (document.activeElement !== psel) {
    psel.innerHTML = '';
    if (!curMap && !curPlace) psel.appendChild(new Option(S.hasScan ? 'Unnamed map (not saved by name)' : 'No map', ''));
    maps.forEach(m => psel.appendChild(new Option(m.name, m.id)));
    places.forEach(p => psel.appendChild(new Option(p.name + ' (Pi' + (p.piCurrent ? ', in use there' : '') + ')', p.id)));
    psel.value = curMap ? curMap.id : curPlace ? curPlace.id : '';
  }
  $('#mapRename').hidden = $('#mapDelete').hidden = !curMap;
  const cam = $('#camInfo');
  if (cam) {
    if (S.usbCameras > 0) cam.textContent = 'Webcam ready' + (S.usbCamName ? ': ' + S.usbCamName : '') + '. Map with webcam projects black, white, then the checkerboard, and saves the map. The camera is released afterwards. Phone photos remain a fallback.';
    else if (S.usbHost) cam.textContent = 'No USB camera found. Plug the C615 into the Astro\'s USB (or a hub), or map with phone photos instead.';
    else cam.textContent = "This Astro doesn't expose USB host, so the webcam can't be used. Map with your phone instead.";
  }
  const camBtn = $('#mapCam');
  if (camBtn) camBtn.disabled = !!S.mapBusy;
  const fps = S.fps ? Math.round(S.fps) + ' fps' : '';
  const upd = $('#updateInfo');
  if (upd) {
    const bits = [];
    bits.push('App v' + (S.version || '') + ' · content ' + (S.contentVersion || '?') + (S.contentSource && S.contentSource !== 'current' ? ' (' + S.contentSource + ')' : ''));
    if (S.updateStatus) bits.push(S.updateStatus);
    upd.textContent = bits.join(' — ');
  }
  const chk = $('#checkUpdate');
  // a downloaded app update can always be installed again (the installer may have been dismissed)
  if (chk) { chk.disabled = !!S.updateBusy && !S.updateReady; chk.textContent = S.updateReady ? 'Install update' : 'Check for update'; }
  if (S.updateStatus) setLine(S.updateStatus, S.updateError ? false : true);
  else if (S.mapStatus) setLine(S.mapStatus, S.mapError ? false : true);
  else setLine((S.banner ? S.banner + '  ·  ' : '') + (S.effect || '') + (fps ? '  ·  ' + fps : ''), true);
  const pl = $('#piLink');
  if (pl) pl.innerHTML = /^https?:\/\//.test(S.piUrl || '') ? 'Pi control panel: <a href="' + encodeURI(S.piUrl) + '">' + S.piUrl.replace(/[<>&"]/g, '') + '</a>' : '';
}

function slider(id, label, min, max, step, val, key) {
  const wrap = document.createElement('label');
  wrap.innerHTML = label + ' <span class=row><input type=range min='+min+' max='+max+' step='+step+' value="'+val+'"> <output>'+val+'</output></span>';
  const inp = wrap.querySelector('input'), out = wrap.querySelector('output');
  inp.oninput = () => { out.textContent = inp.value; };
  inp.onchange = () => { const o = {}; o[key] = +inp.value; save(o); };
  return wrap;
}
function toggle(label, key, val) {
  const wrap = document.createElement('label');
  wrap.innerHTML = '<span class=row>'+label+' <input type=checkbox '+(val?'checked':'')+'></span>';
  wrap.querySelector('input').onchange = ev => { const o = {}; o[key] = ev.target.checked; save(o); };
  return wrap;
}
function select(label, key, val, opts) {
  const wrap = document.createElement('label');
  wrap.appendChild(document.createTextNode(label + ' '));
  const s = document.createElement('select');
  opts.forEach(([v,l]) => { const o = document.createElement('option'); o.value=v; o.textContent=l; if (v===val) o.selected=true; s.appendChild(o); });
  s.onchange = () => { const o = {}; o[key] = s.value; save(o); };
  wrap.appendChild(s); return wrap;
}

function fieldValue(key, fallback) {
  if (S[key] !== undefined && S[key] !== null) return S[key];
  return fallback;
}
function renderFromSchema(box, sliders) {
  sliders.forEach(s => {
    const key = s.key;
    if (!key) return;
    const typ = s.type || (s.options ? 'select' : (typeof s.default === 'boolean' ? 'toggle' : 'slider'));
    if (typ === 'toggle') box.appendChild(toggle(s.label || key, key, !!fieldValue(key, s.default)));
    else if (typ === 'select') box.appendChild(select(s.label || key, key, fieldValue(key, s.default), s.options || []));
    else box.appendChild(slider(key, s.label || key, s.min, s.max, s.step || 0.05, fieldValue(key, s.default), key));
  });
}
function renderSliders() {
  const box = $('#sliders'); box.innerHTML = '<h2>Tuning</h2>';
  const e = S.effect;
  const def = (S.effects || []).find(x => x.id === e);
  if (def && def.sliders && def.sliders.length) {
    renderFromSchema(box, def.sliders);
    return;
  }
  box.appendChild(slider('int', 'Intensity', 0.2, 2, 0.05, S.intensity, 'intensity'));
  box.appendChild(slider('spd', 'Speed', 0.2, 3, 0.05, S.fxSpeed, 'fxSpeed'));
  if (e === 'wax' || e === 'clock') {
    box.appendChild(slider('heat', 'Heat', 0.3, 3, 0.05, S.heat, 'heat'));
    box.appendChild(slider('size', 'Blob size', 0.5, 2, 0.05, S.size, 'size'));
    box.appendChild(slider('blobs', 'Blobs', 2, 16, 1, S.blobs, 'blobs'));
    box.appendChild(slider('pal', 'Palette', 0, 19, 1, S.palette, 'palette'));
    if (e === 'clock') box.appendChild(select('Timezone', 'tz', S.tz, [
      ['America/Los_Angeles','Pacific'], ['America/Denver','Mountain'], ['America/Chicago','Central'],
      ['America/New_York','Eastern'], ['UTC','UTC']
    ]));
  }
  if (e === 'lava') {
  }
  if (e === 'rain') {
    box.appendChild(select('Weather', 'weather', S.weather, [['auto','Auto (take turns)'],['rain','Rain'],['snow','Snow']]));
  }
  if (e === 'ivy') {
    box.appendChild(toggle('Moving sun', 'sunOn', S.sunOn));
    box.appendChild(slider('ss', 'Sun speed', 0.2, 3, 0.05, S.sunSpeed, 'sunSpeed'));
  }
  if (e === 'sweep') {
    box.appendChild(select('Direction', 'sweepMode', S.sweepMode, [['auto','Auto (changes every 45 s)'],['top','From the top'],['sunrise','Sunrise to sunset'],['orbit','Orbit'],['spotlight','Swinging spotlight']]));
  }
  box.appendChild(slider('hue', 'Hue shift', -180, 180, 5, S.hue || 0, 'hue'));
  box.appendChild(slider('sat', 'Saturation', 0, 2, 0.05, S.sat == null ? 1 : S.sat, 'sat'));
  box.appendChild(toggle('Show mask (debug)', 'debugMask', S.debugMask));
}

/* ---- widgets (same settings as the Pi's Widgets card) ---- */
const WIDGETS = [['clock','🕰️ Lava clock'],['weather','⛅ Weather'],['outdoor','🌡️ Outdoor temperature'],
  ['indoor','🏠 Indoor temperature (Nest, via the Pi)'],['car','🔋 Tesla charge'],['door','🔔 Doorbell (Nest, via the Pi)']];
const wOpen = {};
function wSave(o) { return save({ widgets: o }); }
function wRow(label, inner) { const l = document.createElement('label'); l.textContent = label + ' '; l.appendChild(inner); return l; }
function wRange(key, label, min, max, step, val) {
  const wrap = document.createElement('label');
  wrap.innerHTML = label + ' <span class=row><input type=range min='+min+' max='+max+' step='+step+' value="'+val+'"> <output>'+val+'</output></span>';
  const inp = wrap.querySelector('input'), out = wrap.querySelector('output');
  inp.oninput = () => { out.textContent = inp.value; };
  inp.onchange = () => { const o = {}; o[key] = +inp.value; wSave(o); };
  return wrap;
}
function wSelect(key, label, val, opts, top) {
  const s = document.createElement('select');
  opts.forEach(([v,l]) => { const o = document.createElement('option'); o.value=v; o.textContent=l; if (String(v)===String(val)) o.selected=true; s.appendChild(o); });
  s.onchange = () => { const o = {}; o[key] = /^\d+$/.test(s.value) ? +s.value : s.value; top ? save(o) : wSave(o); };
  return wRow(label, s);
}
function wCheck(key, label, val) {
  const l = document.createElement('label');
  l.innerHTML = '<span class=row>' + label + ' <input type=checkbox ' + (val ? 'checked' : '') + '></span>';
  l.querySelector('input').onchange = ev => { const o = {}; o[key] = ev.target.checked; wSave(o); };
  return l;
}
function wColorIn(key, label, val) {
  const i = document.createElement('input'); i.type = 'color'; i.value = val || '#ffffff';
  i.onchange = () => { const o = {}; o[key] = i.value; wSave(o); };
  return wRow(label, i);
}
function renderWidgets() {
  const W = S.widgets || {}, H = S.home || {}, E = H.errors || {};
  const box = $('#wList'); box.innerHTML = '';
  WIDGETS.forEach(([k, label]) => {
    const d = document.createElement('details'); d.open = !!wOpen[k];
    d.ontoggle = () => { wOpen[k] = d.open; };
    const sum = document.createElement('summary');
    const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = !!W[k];
    cb.onclick = ev => ev.stopPropagation();
    cb.onchange = () => { const o = {}; o[k] = cb.checked; wSave(o); };
    sum.appendChild(cb); sum.appendChild(document.createTextNode(' ' + label));
    d.appendChild(sum);
    d.appendChild(wSelect(k + '_spot', 'Spot', W[k + '_spot'] || 1, [[1,'1 (biggest)'],[2,'2'],[3,'3'],[4,'4'],[5,'5']]));
    d.appendChild(wRange(k + '_size', 'Size', 0.3, 1.5, 0.05, W[k + '_size'] || 1));
    d.appendChild(wRange(k + '_rot', 'Rotate', -180, 180, 5, W[k + '_rot'] || 0));
    if (k === 'clock') {
      d.appendChild(wSelect('clock_face', 'Face', W.clock_face || 'analog', [['analog','Wax hands'],['orbit','Orbit'],['neon','Neon tube'],['digital','Digital'],['segments','Digital (segments)']]));
      d.appendChild(wSelect('clock_ink', 'Colour', W.clock_ink || 'lava', [['lava','The lava palette'],['colour','My colour']]));
      if (W.clock_ink === 'colour' || W.clock_ink === 'color') {
        d.appendChild(wColorIn('clock_color', 'Clock colour', W.clock_color || '#ff8030'));
        d.appendChild(wColorIn('clock_color2', 'Seconds / date colour', W.clock_color2 || '#ffc090'));
      }
      d.appendChild(wRange('clock_back', 'Dark backing', 0, 1, 0.05, W.clock_back == null ? 0.8 : W.clock_back));
      d.appendChild(wCheck('h24', '24-hour', W.h24));
      d.appendChild(wCheck('date', 'Date (digital faces)', W.date !== false));
      d.appendChild(wSelect('tz', 'Time zone', S.tz, [['America/Los_Angeles','Pacific'],['America/Denver','Mountain'],['America/Chicago','Central'],['America/New_York','Eastern'],['UTC','UTC']], true));
    }
    if (k === 'door') {
      d.appendChild(wRange('door_s', 'Show for (seconds)', 10, 300, 5, W.door_s || 45));
      d.appendChild(wCheck('door_flash', 'Flash when it rings', W.door_flash !== false));
      const b = document.createElement('button'); b.type = 'button'; b.textContent = 'Test ring';
      b.onclick = () => save({ testRing: true }); d.appendChild(b);
    }
    box.appendChild(d);
  });
  $('#wFont').value = W.font || 'bubble';
  $('#wColor').value = W.color || '#ffffff';
  if (document.activeElement !== $('#wZip')) $('#wZip').value = W.zip || '';
  const wx = H.weather;
  $('#wZipInfo').textContent = E.weather ? E.weather : (W.place ? W.place + (wx ? ': ' + Math.round(wx.f) + '°F' : '') : 'Open-Meteo, no account needed.');
  $('#wCarInfo').textContent = E.car ? E.car : (S.tessieSet ? 'Token saved on the Astro.' + (H.car ? ' ' + H.car.name + ': ' + H.car.level + '%' : '') : "Leave empty to use the Pi's Tessie instead.");
  $('#wPiInfo').textContent = E.pi ? E.pi : (H.indoor != null ? 'From the Pi: inside ' + Math.round(H.indoor) + '°F' : '');
}
$('#wFont').onchange = () => wSave({ font: $('#wFont').value });
$('#wColor').onchange = () => wSave({ color: $('#wColor').value });
$('#wSpots').onclick = () => save({ findSpots: true });
$('#wZipSave').onclick = () => wSave({ zip: $('#wZip').value.trim() });
$('#wTessieSave').onclick = () => { save({ tessieToken: $('#wTessie').value.trim() }); $('#wTessie').value = ''; };

async function save(partial) {
  try { S = await api('/api/state', partial); await refresh(); }
  catch (e) { setStatus(String(e.message || e), false); }
}

$('#piImport').onclick = async () => {
  try {
    setStatus('Importing from the Pi…');
    await api('/api/import/pi', { url: $('#piUrl').value || S.piUrl });
    await refresh(); setStatus((S.places || []).length ? 'Imported ' + S.places.length + ' maps from the Pi' : 'Imported the Pi map', true);
  } catch (e) { setStatus('Pi import: ' + (e.message || e), false); }
};
$('#place').onchange = async () => {
  const id = $('#place').value; if (!id) return;
  try { S = await api('/api/place', { id }); await refresh(); setStatus('Using ' + $('#place').selectedOptions[0].text, true); }
  catch (e) { setStatus('Map: ' + (e.message || e), false); }
};
$('#usbImport').onclick = async () => {
  try { await api('/api/import/usb', {}); await refresh(); setStatus('Imported from USB', true); }
  catch (e) { setStatus('USB: ' + (e.message || e), false); }
};
$('#mapRename').onclick = async () => {
  const cur = (S.maps || []).find(m => m.active); if (!cur) return;
  const name = prompt('New name for this map', cur.name); if (!name || !name.trim()) return;
  try { S = await api('/api/maps/rename', { id: cur.id, name: name.trim() }); await refresh(); setStatus('Renamed to "' + name.trim() + '"', true); }
  catch (e) { setStatus('Rename: ' + (e.message || e), false); }
};
$('#mapDelete').onclick = async () => {
  const cur = (S.maps || []).find(m => m.active); if (!cur) return;
  if (!confirm('Delete the saved map "' + cur.name + '"? The wall keeps using it until you pick another.')) return;
  try { S = await api('/api/maps/delete', { id: cur.id }); await refresh(); setStatus('Deleted "' + cur.name + '"', true); }
  catch (e) { setStatus('Delete: ' + (e.message || e), false); }
};
$('#scanClear').onclick = async () => {
  if (!confirm('Clear the map? Effects will fill the whole wall.')) return;
  try { await api('/api/scan/clear', {}); await refresh(); } catch (e) { setStatus(String(e.message||e), false); }
};

/* ---- mapping: a step-by-step wizard ----
   1 White photo (Gemini looks at it)  2 Checker photo (lines the map up)  3 Objects (Gemini, through the Pi)  4 Name and save.
   A frame that holds the other objects becomes the bounding box, so effects stay inside it. */
const MapUI = {
  photos: [], // [ , white, checker] as {frame, img, file}
  mask: null, objects: null, box: null, step: 0,
};
const MAP_NAMES = ['black', 'white', 'checker'];
const MAP_SHOT = {
  1: 'The projector is showing white with four colour corners. Stand back so the whole projection is in the photo, keep all four corners visible, then take the photo.',
  2: 'Now the checkerboard. Take the second photo from the same spot.',
};
function mapStepTo(n) {
  MapUI.step = n;
  document.querySelectorAll('#mapSteps li').forEach(li => {
    const s = +li.dataset.s; li.className = s < n ? 'done' : s === n ? 'on' : '';
  });
  const shoot = n <= 2;
  $('#mapShot').hidden = $('#mapPick').hidden = !shoot;
  $('#mapBack').hidden = n <= 1;
  $('#mapNameRow').hidden = $('#mapSave').hidden = n < 4;
  $('#mapPrev').hidden = n < 3;
  $('#mapRetry').hidden = true;
  if (shoot) { $('#mapStep').textContent = 'Photo ' + n + ' of 2. ' + MAP_SHOT[n]; mapProgress(null); }
}
// the bar: a fraction 0..1, or {secs} to creep towards 90% while waiting on something slow, or null to hide it
let progT = 0;
function mapProgress(v) {
  const bar = $('#mapProg'), fill = bar.firstElementChild;
  clearInterval(progT);
  if (v === null) { bar.hidden = true; return; }
  bar.hidden = false;
  if (typeof v === 'number') { fill.style.width = Math.round(v * 100) + '%'; return; }
  const t0 = Date.now();
  fill.style.width = '3%';
  progT = setInterval(() => { const f = 1 - Math.exp(-(Date.now() - t0) / 1000 / v.secs * 2.3); fill.style.width = Math.round(3 + 87 * f) + '%'; }, 300);
}
// A thumbnail per photo with the corners the mapper found, so a bad shot shows straight away.
async function mapThumbs() {
  const box = $('#mapThumbs'); box.textContent = '';
  const spec = await api('/api/map/spec');
  let allOk = true;
  Mapper.alignSet(MapUI.photos.map(p => p && p.img));
  for (const p of MapUI.photos) {
    if (!p) continue;
    const fig = document.createElement('figure');
    const c = document.createElement('canvas'); c.width = 240; c.height = 135;
    const r = Mapper.drawFound(c, p.img, spec);
    const cap = document.createElement('figcaption');
    cap.textContent = MAP_NAMES[p.frame] + (r.ok ? ' ✓' : ' ✗ ' + r.error);
    if (!r.ok) { fig.className = 'bad'; allOk = false; }
    fig.append(c, cap); box.append(fig);
  }
  $('#mapDl').hidden = !MapUI.photos.some(p => p && p.file);
  return allOk;
}
async function mapDownload() {
  const files = MapUI.photos.filter(p => p && p.file).map(p => {
    const ext = (p.file.name.match(/\.\w+$/) || ['.jpg'])[0];
    return new File([p.file], 'lava-map-' + MAP_NAMES[p.frame] + ext, { type: p.file.type || 'image/jpeg' });
  });
  if (!files.length) return;
  try {
    if (navigator.canShare && navigator.canShare({ files })) { await navigator.share({ files, title: 'Lava mapping photos' }); return; }
  } catch (e) { if (e.name === 'AbortError') return; }
  for (const f of files) {
    const a = document.createElement('a'); a.href = URL.createObjectURL(f); a.download = f.name;
    document.body.append(a); a.click(); a.remove();
    await new Promise(r => setTimeout(r, 400));
  }
}
$('#mapDl').onclick = () => mapDownload();
$('#olCard').addEventListener('toggle', () => { if ($('#olCard').open) Outline.open(); });
$('#mapCam').onclick = () => mapWebcam();
$('#mapStart').onclick = () => mapBegin();

async function mapWebcam() {
  try {
    setStatus('Starting webcam mapping…');
    await api('/api/map/webcam', {});
    for (let i = 0; i < 90; i++) {
      await new Promise(r => setTimeout(r, 700));
      await refresh();
      if (!S.mapBusy) {
        setStatus(S.mapStatus || (S.mapError ? 'Webcam mapping failed.' : 'Webcam map saved.'), S.mapError ? false : true);
        return;
      }
    }
    setStatus(S.mapStatus || 'Still mapping… refresh the page if this stalls.', false);
  } catch (e) {
    setStatus('Webcam: ' + (e.message || e), false);
  }
}

$('#mapBatch').onclick = () => $('#batch').click();
$('#mapShot').onclick = () => $('#shot').click();
$('#mapPick').onclick = () => $('#pick').click();
$('#mapBack').onclick = () => mapBackStep();
$('#mapCancel').onclick = () => mapEnd(true);
$('#mapSave').onclick = () => mapSave();
$('#mapRetry').onclick = () => { MapUI.gemFor = null; mapObjects(); };
// the photo this page asked for, not S.mapPattern: that copy of the Astro's state can be stale, and a stale 0 filed every
// photo as the black one, so mapping never got past photo 1
const gotShot = ev => { const f = ev.target.files[0]; ev.target.value = ''; if (f && MapUI.step <= 2) mapGotFile(f, MapUI.step || 1); };
$('#shot').onchange = gotShot;
$('#pick').onchange = gotShot;
$('#batch').onchange = ev => { mapBatch(ev.target.files); ev.target.value = ''; };

async function mapShow(frame) {
  try { await api('/api/map', { action: frame ? 'frame' : 'stop', frame }); } catch (e) { setStatus('Projector: ' + (e.message || e), false); }
}
function mapReset() {
  MapUI.photos = []; MapUI.mask = null; MapUI.objects = null; MapUI.box = null; MapUI.gemFor = null; MapUI.photo = null; MapUI.build = null;
  $('#mapGem').hidden = true; $('#mapThumbs').textContent = ''; $('#mapDl').hidden = true; $('#mapName').value = '';
}
async function mapBegin() {
  mapReset();
  $('#mapUi').hidden = false;
  $('#mapUi').scrollIntoView({ behavior: 'smooth', block: 'start' });
  await api('/api/map', { action: 'start', frame: 1 }).catch(() => {});
  await mapShow(1);
  mapStepTo(1);
}
async function mapBackStep() {
  const n = Math.max(1, Math.min(MapUI.step - 1, 2));
  // going back to a photo means taking it again
  for (let f = n; f <= 2; f++) MapUI.photos[f] = undefined;
  MapUI.objects = null; MapUI.box = null; MapUI.gemFor = null; $('#mapGem').hidden = true;
  await mapThumbs();
  await mapShow(n);
  mapStepTo(n);
}
async function mapGotFile(file, frame) {
  mapProgress(0.3); $('#mapStep').textContent = 'Reading photo ' + frame + '…';
  const img = await Mapper.loadImage(file);
  MapUI.photos[frame] = { frame, img, file };
  const ok = await mapThumbs();
  if (!ok) {
    mapStepTo(frame);
    $('#mapStep').textContent = 'Photo ' + frame + ": I couldn't find all four colour corners. Take it again with the whole projection in view.";
    setStatus('Photo ' + frame + ': corners not found. Take it again.', false);
    return;
  }
  if (frame === 1) { await mapShow(2); mapStepTo(2); setStatus('Got the white photo', true); return; }
  await mapShow(0);
  await mapObjects();
}
async function mapBatch(files) {
  mapReset();
  $('#mapUi').hidden = false;
  mapStepTo(1); mapProgress(0.2);
  $('#mapStep').textContent = 'Reading ' + files.length + ' photos…';
  const imgs = [], byImg = new Map();
  for (const f of files) { const im = await Mapper.loadImage(f); imgs.push(im); byImg.set(im, f); }
  const spec = await api('/api/map/spec');
  try {
    Mapper.classify(imgs, spec).forEach(p => { if (p) MapUI.photos[p.frame] = Object.assign(p, { file: byImg.get(p.img) }); });
  } catch (e) {
    imgs.slice(0, 2).forEach((img, i) => { MapUI.photos[i + 1] = { frame: i + 1, img, file: byImg.get(img) }; });
    await mapThumbs(); mapProgress(null);
    setStatus('Mapping: ' + e.message, false); return;
  }
  await mapThumbs();
  await mapShow(0);
  await mapObjects();
}

// the outlines Gemini gave, as the mask and the preview
function polyMask(objs, box) {
  const c = document.createElement('canvas'); c.width = 854; c.height = 480;
  const g = c.getContext('2d'); g.fillStyle = '#fff';
  const path = pts => { g.beginPath(); pts.forEach((p, k) => k ? g.lineTo(p[0] * 854, p[1] * 480) : g.moveTo(p[0] * 854, p[1] * 480)); g.closePath(); };
  if (box) { g.fillRect(0, 0, 854, 480); g.fillStyle = '#000'; path(box); g.fill(); g.fillStyle = '#fff'; }
  objs.forEach(o => { path(o.pts); g.fill(); });
  const d = g.getImageData(0, 0, 854, 480).data, m = new Uint8Array(854 * 480);
  for (let i = 0; i < m.length; i++) m[i] = d[i * 4] > 127 ? 255 : 0;
  return m;
}
// A frame (or any big shape) that holds at least two other objects is the bounding box, not an object.
function splitFrame(objs) {
  const bb = o => { const xs = o.pts.map(p => p[0]), ys = o.pts.map(p => p[1]); return [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)]; };
  const centre = o => { const b = bb(o); return [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2]; };
  let best = null, bestN = 1;
  objs.forEach(o => {
    const b = bb(o);
    const n = objs.filter(q => q !== o && (([x, y]) => x > b[0] && x < b[2] && y > b[1] && y < b[3])(centre(q))).length;
    const named = /frame|border|board|canvas|panel|picture|poster|sign/i.test(o.label);
    if (n > bestN || (n === bestN && n >= 2 && named)) { best = o; bestN = n; }
  });
  if (!best) return { box: null, objs };
  const b = bb(best);
  return { box: [[b[0], b[1]], [b[2], b[1]], [b[2], b[3]], [b[0], b[3]]], boxLabel: best.label, objs: objs.filter(o => o !== best) };
}
function mapDraw() {
  const r = MapUI.build, cv = $('#mapPrev'), k = cv.width / 854;
  const mask = MapUI.mask, pv = r.preview.rgba, wr = r.white.rgba;
  // objects tinted pink; outside the bounding box dimmed (effects don't go there)
  const obj = MapUI.box ? polyMask(MapUI.objects || [], null) : mask;
  for (let i = 0; i < mask.length; i++) {
    const R = wr[i*4], G = wr[i*4+1], B = wr[i*4+2];
    if (obj[i]) { pv[i*4] = Math.min(255, R + 90); pv[i*4+1] = G * 0.7; pv[i*4+2] = Math.min(255, B + 50); }
    else if (mask[i]) { pv[i*4] = R * 0.35; pv[i*4+1] = G * 0.35; pv[i*4+2] = B * 0.35; }
    else { pv[i*4] = R; pv[i*4+1] = G; pv[i*4+2] = B; }
  }
  Mapper.drawPreview(cv, r);
  const g = cv.getContext('2d');
  const path = pts => { g.beginPath(); pts.forEach((p, j) => j ? g.lineTo(p[0] * 854 * k, p[1] * 480 * k) : g.moveTo(p[0] * 854 * k, p[1] * 480 * k)); g.closePath(); };
  g.font = 'bold 22px system-ui'; g.lineWidth = 3;
  if (MapUI.box) { g.setLineDash([12, 8]); g.strokeStyle = g.fillStyle = '#ffd34d'; path(MapUI.box); g.stroke(); g.setLineDash([]);
    g.fillText('bounding box', MapUI.box[0][0] * 854 * k + 6, MapUI.box[0][1] * 480 * k + 24); }
  if (MapUI.objects) {
    g.strokeStyle = g.fillStyle = '#7fdcff';
    MapUI.objects.forEach(o => { path(o.pts); g.stroke(); g.fillText(o.label, o.pts[0][0] * 854 * k + 4, o.pts[0][1] * 480 * k - 6); });
  }
}
// step 3: line the photos up, then ask Gemini for the objects
async function mapObjects() {
  mapStepTo(3);
  if (!MapUI.photos[1]) { mapStepTo(1); setStatus('Need the white photo', false); return; }
  $('#mapStep').textContent = 'Lining up the photos…'; mapProgress(0.5);
  await new Promise(r => setTimeout(r, 30));              // let the bar paint before the heavy work
  const spec = await api('/api/map/spec');
  try {
    MapUI.build = Mapper.build(MapUI.photos.filter(Boolean), spec, 18);
    try { MapUI.photo = Mapper.photoJpeg(MapUI.build.white); } catch (e) { MapUI.photo = null; }
  } catch (e) { mapProgress(null); mapStepTo(2); $('#mapStep').textContent = 'Mapping: ' + e.message + ' Take the photos again.'; setStatus('Mapping: ' + e.message, false); return; }
  MapUI.mask = new Uint8Array(854 * 480); MapUI.objects = null; MapUI.box = null;
  mapDraw();
  if (!MapUI.photo) return mapFallback('no photo to send');
  MapUI.gemFor = MapUI.photo;
  $('#mapStep').textContent = 'Asking Gemini to find the objects. This takes up to a minute…';
  const note = $('#mapGem'); note.hidden = true;
  mapProgress({ secs: 35 });
  let sg;
  try { sg = await api('/api/gemini', { photo: MapUI.photo }); }
  catch (e) { return mapFallback(e.message || String(e)); }
  if (sg.error) return mapFallback(sg.error);
  const all = (sg.props || []).map((p, i) => Outline.fromProp(p, i)).filter(Boolean);
  if (!all.length) return mapFallback('it found nothing to outline');
  const sp = splitFrame(all);
  MapUI.objects = sp.objs; MapUI.box = sp.box;
  MapUI.mask = polyMask(MapUI.objects, MapUI.box);
  mapProgress(1);
  mapDraw();
  note.hidden = false;
  note.textContent = 'Gemini found: ' + MapUI.objects.map(o => o.label).join(', ') + '.' + (MapUI.box ? ' The ' + sp.boxLabel + ' is the bounding box, so effects stay inside it.' : '');
  mapReady('Objects are outlined in blue. Looks right? Name the map and save it. You can fine-tune the outlines after saving.');
}
// Gemini didn't help: use what brightness finds, and say so
function mapFallback(why) {
  const r = MapUI.build;
  MapUI.mask = r.mask; MapUI.objects = null; MapUI.box = null;
  mapDraw();
  const note = $('#mapGem'); note.hidden = false;
  note.textContent = 'Gemini: ' + why + '. Using what stands out by brightness (tinted pink) instead.';
  mapReady('Check the preview, then name the map and save it, or ask Gemini again.');
  $('#mapRetry').hidden = false;
}
function mapReady(msg) {
  mapProgress(null);
  mapStepTo(4);
  $('#mapStep').textContent = msg;
  if (!$('#mapName').value) {
    const cur = (S.maps || []).find(m => m.active);
    $('#mapName').value = cur ? cur.name : '';
  }
}
// step 4: save on the Astro under a name
async function mapSave() {
  if (!MapUI.mask) { setStatus('Nothing to save yet', false); return; }
  const name = $('#mapName').value.trim();
  if (!name) { setStatus('Give the map a name first', false); $('#mapName').focus(); return; }
  const r4 = v => Math.round(v * 10000) / 10000;
  const objs = MapUI.objects || [];
  $('#mapSave').disabled = true; mapProgress(0.4);
  try {
    if (objs.length || MapUI.box) {
      const scene = {
        rock: MapUI.box ? MapUI.box.map(p => p.map(r4)) : [],
        props: objs.map(o => o.pts.map(p => p.map(r4))),
        objects: objs.map(o => ({ label: o.label, shape: 'poly', points: o.pts.map(p => p.map(r4)) })),
      };
      await api('/api/scan', { scene, source: 'phone', name, photo: MapUI.photo || undefined });
    } else {
      await api('/api/scan', { source: 'phone', name, mask_png: Mapper.maskPng(MapUI.mask), photo: MapUI.photo || undefined });
    }
    mapProgress(0.8);
    let named = true;
    try { await api('/api/maps/save', { name }); } catch (e) { named = false; }
    window._mapPhoto = MapUI.photo;
    mapProgress(1);
    setStatus(named ? 'Saved "' + name + '" on the Astro' : 'Map saved. Update the app (Settings) to keep it under its name.', true);
    $('#mapUi').hidden = true; mapReset(); mapProgress(null);
    await refresh();
  } catch (e) { mapProgress(null); setStatus('Save: ' + (e.message || e), false); }
  finally { $('#mapSave').disabled = false; }
}
async function mapEnd(cancel) {
  await mapShow(0);
  $('#mapUi').hidden = true;
  mapReset(); mapProgress(null);
  if (cancel) setStatus('Mapping cancelled');
}

refresh().catch(e => setStatus('Cannot reach the Astro: ' + e.message, false));
setInterval(() => { if (S) api('/api/state').then(s => { S.fps = s.fps; }).catch(() => {}); }, 4000);

$('#checkUpdate').onclick = async () => {
  try {
    const r = await api('/api/update/check', {});
    setStatus(r.ready ? 'Opening the installer on the projector: highlight Install and press OK on the remote.' : 'Checking for updates…', true);
    setTimeout(() => refresh().catch(() => {}), 3000);
  } catch (e) { setStatus('Update: ' + (e.message || e), false); }
};
$('#showQr').onclick = async () => {
  try { await api('/api/qr', {}); setStatus('QR codes are on the Astro for 20 seconds', true); }
  catch (e) { setStatus('Show QR: ' + (e.message || e), false); }
};
